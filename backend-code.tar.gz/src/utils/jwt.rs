use jsonwebtoken::{decode, encode, Algorithm, DecodingKey, EncodingKey, Header, Validation};
use serde::{Deserialize, Serialize};
use std::env;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::model::user::UserType;

#[derive(Debug, Serialize, Deserialize)]
pub struct Claims {
    pub sub: String, // 用户ID
    pub user_type: UserType,
    pub exp: u64,     // 过期时间
    pub iat: u64,     // 签发时间
    pub jti: String,  // JWT ID
}

/// 生成JWT Token
pub fn generate_token(user_id: i32, user_type: UserType) -> Result<String, String> {
    let secret = env::var("JWT_SECRET").unwrap_or_else(|_| "default_secret_key".to_string());
    let access_token_expire = env::var("ACCESS_TOKEN_EXPIRE_SECS")
        .unwrap_or_else(|_| "3600".to_string())
        .parse::<u64>()
        .unwrap_or(3600);

    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs();

    let claims = Claims {
        sub: user_id.to_string(),
        user_type,
        exp: now + access_token_expire,
        iat: now,
        jti: uuid::Uuid::new_v4().to_string(),
    };

    let header = Header::new(Algorithm::HS256);
    let encoding_key = EncodingKey::from_secret(secret.as_bytes());

    encode(&header, &claims, &encoding_key)
        .map_err(|e| e.to_string())
}

/// 生成刷新Token
pub fn generate_refresh_token(user_id: i32, user_type: UserType) -> Result<String, String> {
    let secret = env::var("JWT_REFRESH_SECRET").unwrap_or_else(|_| "default_refresh_secret_key".to_string());
    let refresh_token_expire = env::var("REFRESH_TOKEN_EXPIRE_SECS")
        .unwrap_or_else(|_| "604800".to_string())
        .parse::<u64>()
        .unwrap_or(604800); // 7 days

    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs();

    let claims = Claims {
        sub: user_id.to_string(),
        user_type,
        exp: now + refresh_token_expire,
        iat: now,
        jti: uuid::Uuid::new_v4().to_string(),
    };

    let header = Header::new(Algorithm::HS256);
    let encoding_key = EncodingKey::from_secret(secret.as_bytes());

    encode(&header, &claims, &encoding_key)
        .map_err(|e| e.to_string())
}

/// 验证JWT Token
pub fn verify_token(token: &str) -> Result<Claims, String> {
    let secret = env::var("JWT_SECRET").unwrap_or_else(|_| "default_secret_key".to_string());
    let decoding_key = DecodingKey::from_secret(secret.as_bytes());

    decode::<Claims>(token, &decoding_key, &Validation::new(Algorithm::HS256))
        .map(|data| data.claims)
        .map_err(|e| e.to_string())
}

/// 验证刷新Token
pub fn verify_refresh_token(token: &str) -> Result<Claims, String> {
    let secret = env::var("JWT_REFRESH_SECRET").unwrap_or_else(|_| "default_refresh_secret_key".to_string());
    let decoding_key = DecodingKey::from_secret(secret.as_bytes());

    decode::<Claims>(token, &decoding_key, &Validation::new(Algorithm::HS256))
        .map(|data| data.claims)
        .map_err(|e| e.to_string())
}
