use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct User {
    pub id: i32,
    pub username: String,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub password_hash: String,
    pub user_type: UserType,
    pub status: UserStatus,
    pub created_at: NaiveDateTime,
    pub updated_at: NaiveDateTime,
}

#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq)]
pub enum UserType {
    Admin,
    Teacher,
    Student,
}

impl From<&str> for UserType {
    fn from(s: &str) -> Self {
        match s {
            "admin" => UserType::Admin,
            "teacher" => UserType::Teacher,
            "student" => UserType::Student,
            _ => UserType::Student,
        }
    }
}

impl ToString for UserType {
    fn to_string(&self) -> String {
        match self {
            UserType::Admin => "admin".to_string(),
            UserType::Teacher => "teacher".to_string(),
            UserType::Student => "student".to_string(),
        }
    }
}

#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq)]
pub enum UserStatus {
    Active,
    Inactive,
}

impl From<&str> for UserStatus {
    fn from(s: &str) -> Self {
        match s {
            "active" => UserStatus::Active,
            "inactive" => UserStatus::Inactive,
            _ => UserStatus::Active,
        }
    }
}

impl ToString for UserStatus {
    fn to_string(&self) -> String {
        match self {
            UserStatus::Active => "active".to_string(),
            UserStatus::Inactive => "inactive".to_string(),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct NewUser {
    pub username: String,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub password_hash: String,
    pub user_type: UserType,
    pub status: UserStatus,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdateUser {
    pub username: Option<String>,
    pub email: Option<Option<String>>,
    pub phone: Option<Option<String>>,
    pub password_hash: Option<String>,
    pub user_type: Option<UserType>,
    pub status: Option<UserStatus>,
}
