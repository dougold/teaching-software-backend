use chrono::NaiveDateTime;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::schema::activation_codes;

#[derive(Debug, Serialize, Deserialize, Queryable, Selectable)]
#[diesel(table_name = activation_codes)]
#[diesel(check_for_backend(diesel::pg::Pg))]
pub struct ActivationCode {
    pub id: i32,
    pub code: String,
    pub valid_until: NaiveDateTime,
    pub used_by: Option<i32>,
    pub status: ActivationStatus,
    pub created_at: NaiveDateTime,
    pub updated_at: NaiveDateTime,
}

#[derive(Debug, Serialize, Deserialize, FromSqlRow, AsExpression, Clone, Copy)]
#[diesel(sql_type = diesel::sql_types::Text)]
pub enum ActivationStatus {
    Unused,
    Used,
    Expired,
}

#[derive(Debug, Insertable)]
#[diesel(table_name = activation_codes)]
pub struct NewActivationCode {
    pub code: String,
    pub valid_until: NaiveDateTime,
    pub status: ActivationStatus,
}

#[derive(Debug, AsChangeset)]
#[diesel(table_name = activation_codes)]
pub struct UpdateActivationCode {
    pub used_by: Option<Option<i32>>,
    pub status: Option<ActivationStatus>,
}

// 实现FromSql和ToSql for ActivationStatus
impl<DB> diesel::serialize::ToSql<diesel::sql_types::Text, DB> for ActivationStatus
where
    DB: diesel::backend::Backend,
    for<'a> &'a str: diesel::serialize::ToSql<diesel::sql_types::Text, DB>,
{
    fn to_sql<'b>(
        &'b self,
        out: &mut diesel::serialize::Output<'b, '_, DB>,
    ) -> diesel::serialize::Result {
        let s = match self {
            ActivationStatus::Unused => "unused",
            ActivationStatus::Used => "used",
            ActivationStatus::Expired => "expired",
        };
        diesel::serialize::ToSql::<diesel::sql_types::Text, DB>::to_sql(s, out)
    }
}

impl<DB> diesel::deserialize::FromSql<diesel::sql_types::Text, DB> for ActivationStatus
where
    DB: diesel::backend::Backend,
    String: diesel::deserialize::FromSql<diesel::sql_types::Text, DB>,
{
    fn from_sql(bytes: DB::RawValue<'_>) -> diesel::deserialize::Result<Self> {
        let s = String::from_sql(bytes)?;
        match s.as_str() {
            "unused" => Ok(ActivationStatus::Unused),
            "used" => Ok(ActivationStatus::Used),
            "expired" => Ok(ActivationStatus::Expired),
            _ => Err("Invalid activation status".into()),
        }
    }
}
