use chrono::NaiveDateTime;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::schema::scores;

#[derive(Debug, Serialize, Deserialize, Queryable, Selectable)]
#[diesel(table_name = scores)]
#[diesel(check_for_backend(diesel::pg::Pg))]
pub struct Score {
    pub id: i32,
    pub exam_session_id: i32,
    pub student_id: i32,
    pub total_score: i32,
    pub objective_score: i32,
    pub subjective_score: i32,
    pub is_graded: bool,
    pub graded_by: Option<i32>,
    pub graded_at: Option<NaiveDateTime>,
    pub created_at: NaiveDateTime,
    pub updated_at: NaiveDateTime,
}

#[derive(Debug, Insertable)]
#[diesel(table_name = scores)]
pub struct NewScore {
    pub exam_session_id: i32,
    pub student_id: i32,
    pub total_score: i32,
    pub objective_score: i32,
    pub subjective_score: i32,
    pub is_graded: bool,
    pub graded_by: Option<i32>,
    pub graded_at: Option<NaiveDateTime>,
}

#[derive(Debug, AsChangeset)]
#[diesel(table_name = scores)]
pub struct UpdateScore {
    pub total_score: Option<i32>,
    pub objective_score: Option<i32>,
    pub subjective_score: Option<i32>,
    pub is_graded: Option<bool>,
    pub graded_by: Option<Option<i32>>,
    pub graded_at: Option<Option<NaiveDateTime>>,
}
