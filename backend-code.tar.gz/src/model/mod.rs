use diesel::prelude::*;
use serde::{Deserialize, Serialize};

pub mod user;
pub mod activation_code;
pub mod paper;
pub mod question;
pub mod exam_session;
pub mod score;
pub mod question_bank;
pub mod points_record;

// 导入所有模型
pub use user::*;
pub use activation_code::*;
pub use paper::*;
pub use question::*;
pub use exam_session::*;
pub use score::*;
pub use question_bank::*;
pub use points_record::*;
