use chrono::NaiveDateTime;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::schema::points_records;

#[derive(Debug, Serialize, Deserialize, Queryable, Selectable)]
#[diesel(table_name = points_records)]
#[diesel(check_for_backend(diesel::pg::Pg))]
pub struct PointsRecord {
    pub id: i32,
    pub student_id: i32,
    pub points: i32,  // 正数为增加，负数为减少
    pub reason: String,
    pub related_id: Option<i32>,
    pub related_type: Option<String>,
    pub created_at: NaiveDateTime,
}

#[derive(Debug, Insertable)]
#[diesel(table_name = points_records)]
pub struct NewPointsRecord {
    pub student_id: i32,
    pub points: i32,
    pub reason: String,
    pub related_id: Option<i32>,
    pub related_type: Option<String>,
}
