use chrono::NaiveDateTime;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::schema::papers;

#[derive(Debug, Serialize, Deserialize, Queryable, Selectable)]
#[diesel(table_name = papers)]
#[diesel(check_for_backend(diesel::pg::Pg))]
pub struct Paper {
    pub id: i32,
    pub title: String,
    pub subject_id: i32,
    pub created_by: i32,
    pub total_score: i32,
    pub duration: i32, // 分钟
    pub paper_type: PaperType,
    pub status: PaperStatus,
    pub created_at: NaiveDateTime,
    pub updated_at: NaiveDateTime,
}

#[derive(Debug, Serialize, Deserialize, FromSqlRow, AsExpression, Clone, Copy)]
#[diesel(sql_type = diesel::sql_types::Text)]
pub enum PaperType {
    Original,    // 原始导入
    Template,    // 模板
    Generated,   // AI生成
}

#[derive(Debug, Serialize, Deserialize, FromSqlRow, AsExpression, Clone, Copy)]
#[diesel(sql_type = diesel::sql_types::Text)]
pub enum PaperStatus {
    Draft,       // 草稿
    Published,   // 已发布
    Archived,    // 已归档
}

#[derive(Debug, Insertable)]
#[diesel(table_name = papers)]
pub struct NewPaper {
    pub title: String,
    pub subject_id: i32,
    pub created_by: i32,
    pub total_score: i32,
    pub duration: i32,
    pub paper_type: PaperType,
    pub status: PaperStatus,
}

#[derive(Debug, AsChangeset)]
#[diesel(table_name = papers)]
pub struct UpdatePaper {
    pub title: Option<String>,
    pub subject_id: Option<i32>,
    pub total_score: Option<i32>,
    pub duration: Option<i32>,
    pub paper_type: Option<PaperType>,
    pub status: Option<PaperStatus>,
}

// 实现FromSql和ToSql for PaperType
impl<DB> diesel::serialize::ToSql<diesel::sql_types::Text, DB> for PaperType
where
    DB: diesel::backend::Backend,
    for<'a> &'a str: diesel::serialize::ToSql<diesel::sql_types::Text, DB>,
{
    fn to_sql<'b>(
        &'b self,
        out: &mut diesel::serialize::Output<'b, '_, DB>,
    ) -> diesel::serialize::Result {
        let s = match self {
            PaperType::Original => "original",
            PaperType::Template => "template",
            PaperType::Generated => "generated",
        };
        diesel::serialize::ToSql::<diesel::sql_types::Text, DB>::to_sql(s, out)
    }
}

impl<DB> diesel::deserialize::FromSql<diesel::sql_types::Text, DB> for PaperType
where
    DB: diesel::backend::Backend,
    String: diesel::deserialize::FromSql<diesel::sql_types::Text, DB>,
{
    fn from_sql(bytes: DB::RawValue<'_>) -> diesel::deserialize::Result<Self> {
        let s = String::from_sql(bytes)?;
        match s.as_str() {
            "original" => Ok(PaperType::Original),
            "template" => Ok(PaperType::Template),
            "generated" => Ok(PaperType::Generated),
            _ => Err("Invalid paper type".into()),
        }
    }
}

// 实现FromSql和ToSql for PaperStatus
impl<DB> diesel::serialize::ToSql<diesel::sql_types::Text, DB> for PaperStatus
where
    DB: diesel::backend::Backend,
    for<'a> &'a str: diesel::serialize::ToSql<diesel::sql_types::Text, DB>,
{
    fn to_sql<'b>(
        &'b self,
        out: &mut diesel::serialize::Output<'b, '_, DB>,
    ) -> diesel::serialize::Result {
        let s = match self {
            PaperStatus::Draft => "draft",
            PaperStatus::Published => "published",
            PaperStatus::Archived => "archived",
        };
        diesel::serialize::ToSql::<diesel::sql_types::Text, DB>::to_sql(s, out)
    }
}

impl<DB> diesel::deserialize::FromSql<diesel::sql_types::Text, DB> for PaperStatus
where
    DB: diesel::backend::Backend,
    String: diesel::deserialize::FromSql<diesel::sql_types::Text, DB>,
{
    fn from_sql(bytes: DB::RawValue<'_>) -> diesel::deserialize::Result<Self> {
        let s = String::from_sql(bytes)?;
        match s.as_str() {
            "draft" => Ok(PaperStatus::Draft),
            "published" => Ok(PaperStatus::Published),
            "archived" => Ok(PaperStatus::Archived),
            _ => Err("Invalid paper status".into()),
        }
    }
}
