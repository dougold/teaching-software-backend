use chrono::NaiveDateTime;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::schema::exam_sessions;

#[derive(Debug, Serialize, Deserialize, Queryable, Selectable)]
#[diesel(table_name = exam_sessions)]
#[diesel(check_for_backend(diesel::pg::Pg))]
pub struct ExamSession {
    pub id: i32,
    pub paper_id: i32,
    pub title: String,
    pub start_time: NaiveDateTime,
    pub end_time: NaiveDateTime,
    pub created_by: i32,
    pub status: ExamStatus,
    pub created_at: NaiveDateTime,
    pub updated_at: NaiveDateTime,
}

#[derive(Debug, Serialize, Deserialize, FromSqlRow, AsExpression, Clone, Copy)]
#[diesel(sql_type = diesel::sql_types::Text)]
pub enum ExamStatus {
    NotStarted, // 未开始
    Ongoing,    // 进行中
    Ended,      // 已结束
}

#[derive(Debug, Insertable)]
#[diesel(table_name = exam_sessions)]
pub struct NewExamSession {
    pub paper_id: i32,
    pub title: String,
    pub start_time: NaiveDateTime,
    pub end_time: NaiveDateTime,
    pub created_by: i32,
    pub status: ExamStatus,
}

#[derive(Debug, AsChangeset)]
#[diesel(table_name = exam_sessions)]
pub struct UpdateExamSession {
    pub title: Option<String>,
    pub start_time: Option<NaiveDateTime>,
    pub end_time: Option<NaiveDateTime>,
    pub status: Option<ExamStatus>,
}

// 实现FromSql和ToSql for ExamStatus
impl<DB> diesel::serialize::ToSql<diesel::sql_types::Text, DB> for ExamStatus
where
    DB: diesel::backend::Backend,
    for<'a> &'a str: diesel::serialize::ToSql<diesel::sql_types::Text, DB>,
{
    fn to_sql<'b>(
        &'b self,
        out: &mut diesel::serialize::Output<'b, '_, DB>,
    ) -> diesel::serialize::Result {
        let s = match self {
            ExamStatus::NotStarted => "not_started",
            ExamStatus::Ongoing => "ongoing",
            ExamStatus::Ended => "ended",
        };
        diesel::serialize::ToSql::<diesel::sql_types::Text, DB>::to_sql(s, out)
    }
}

impl<DB> diesel::deserialize::FromSql<diesel::sql_types::Text, DB> for ExamStatus
where
    DB: diesel::backend::Backend,
    String: diesel::deserialize::FromSql<diesel::sql_types::Text, DB>,
{
    fn from_sql(bytes: DB::RawValue<'_>) -> diesel::deserialize::Result<Self> {
        let s = String::from_sql(bytes)?;
        match s.as_str() {
            "not_started" => Ok(ExamStatus::NotStarted),
            "ongoing" => Ok(ExamStatus::Ongoing),
            "ended" => Ok(ExamStatus::Ended),
            _ => Err("Invalid exam status".into()),
        }
    }
}
