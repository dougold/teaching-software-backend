use chrono::NaiveDateTime;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::schema::question_banks;

#[derive(Debug, Serialize, Deserialize, Queryable, Selectable)]
#[diesel(table_name = question_banks)]
#[diesel(check_for_backend(diesel::pg::Pg))]
pub struct QuestionBank {
    pub id: i32,
    pub name: String,
    pub subject_id: i32,
    pub description: Option<String>,
    pub created_by: i32,
    pub created_at: NaiveDateTime,
    pub updated_at: NaiveDateTime,
}

#[derive(Debug, Insertable)]
#[diesel(table_name = question_banks)]
pub struct NewQuestionBank {
    pub name: String,
    pub subject_id: i32,
    pub description: Option<String>,
    pub created_by: i32,
}

#[derive(Debug, AsChangeset)]
#[diesel(table_name = question_banks)]
pub struct UpdateQuestionBank {
    pub name: Option<String>,
    pub subject_id: Option<i32>,
    pub description: Option<Option<String>>,
}
