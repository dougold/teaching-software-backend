use chrono::NaiveDateTime;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::schema::questions;

#[derive(Debug, Serialize, Deserialize, Queryable, Selectable)]
#[diesel(table_name = questions)]
#[diesel(check_for_backend(diesel::pg::Pg))]
pub struct Question {
    pub id: i32,
    pub paper_id: Option<i32>,
    pub question_bank_id: Option<i32>,
    pub question_type: QuestionType,
    pub content: String,
    pub image_url: Option<String>,
    pub options: Option<serde_json::Value>,
    pub correct_answer: String,
    pub score: i32,
    pub difficulty: Difficulty,
    pub knowledge_point: Option<String>,
    pub created_at: NaiveDateTime,
    pub updated_at: NaiveDateTime,
}

#[derive(Debug, Serialize, Deserialize, FromSqlRow, AsExpression, Clone, Copy)]
#[diesel(sql_type = diesel::sql_types::Text)]
pub enum QuestionType {
    SingleChoice,   // 单选题
    MultipleChoice, // 多选题
    FillBlank,      // 填空题
    Subjective,     // 主观题
}

#[derive(Debug, Serialize, Deserialize, FromSqlRow, AsExpression, Clone, Copy)]
#[diesel(sql_type = diesel::sql_types::Text)]
pub enum Difficulty {
    Easy,     // 简单
    Medium,   // 中等
    Hard,     // 困难
}

#[derive(Debug, Insertable)]
#[diesel(table_name = questions)]
pub struct NewQuestion {
    pub paper_id: Option<i32>,
    pub question_bank_id: Option<i32>,
    pub question_type: QuestionType,
    pub content: String,
    pub image_url: Option<String>,
    pub options: Option<serde_json::Value>,
    pub correct_answer: String,
    pub score: i32,
    pub difficulty: Difficulty,
    pub knowledge_point: Option<String>,
}

#[derive(Debug, AsChangeset)]
#[diesel(table_name = questions)]
pub struct UpdateQuestion {
    pub paper_id: Option<Option<i32>>,
    pub question_bank_id: Option<Option<i32>>,
    pub question_type: Option<QuestionType>,
    pub content: Option<String>,
    pub image_url: Option<Option<String>>,
    pub options: Option<Option<serde_json::Value>>,
    pub correct_answer: Option<String>,
    pub score: Option<i32>,
    pub difficulty: Option<Difficulty>,
    pub knowledge_point: Option<Option<String>>,
}

// 实现FromSql和ToSql for QuestionType
impl<DB> diesel::serialize::ToSql<diesel::sql_types::Text, DB> for QuestionType
where
    DB: diesel::backend::Backend,
    for<'a> &'a str: diesel::serialize::ToSql<diesel::sql_types::Text, DB>,
{
    fn to_sql<'b>(
        &'b self,
        out: &mut diesel::serialize::Output<'b, '_, DB>,
    ) -> diesel::serialize::Result {
        let s = match self {
            QuestionType::SingleChoice => "single_choice",
            QuestionType::MultipleChoice => "multiple_choice",
            QuestionType::FillBlank => "fill_blank",
            QuestionType::Subjective => "subjective",
        };
        diesel::serialize::ToSql::<diesel::sql_types::Text, DB>::to_sql(s, out)
    }
}

impl<DB> diesel::deserialize::FromSql<diesel::sql_types::Text, DB> for QuestionType
where
    DB: diesel::backend::Backend,
    String: diesel::deserialize::FromSql<diesel::sql_types::Text, DB>,
{
    fn from_sql(bytes: DB::RawValue<'_>) -> diesel::deserialize::Result<Self> {
        let s = String::from_sql(bytes)?;
        match s.as_str() {
            "single_choice" => Ok(QuestionType::SingleChoice),
            "multiple_choice" => Ok(QuestionType::MultipleChoice),
            "fill_blank" => Ok(QuestionType::FillBlank),
            "subjective" => Ok(QuestionType::Subjective),
            _ => Err("Invalid question type".into()),
        }
    }
}

// 实现FromSql和ToSql for Difficulty
impl<DB> diesel::serialize::ToSql<diesel::sql_types::Text, DB> for Difficulty
where
    DB: diesel::backend::Backend,
    for<'a> &'a str: diesel::serialize::ToSql<diesel::sql_types::Text, DB>,
{
    fn to_sql<'b>(
        &'b self,
        out: &mut diesel::serialize::Output<'b, '_, DB>,
    ) -> diesel::serialize::Result {
        let s = match self {
            Difficulty::Easy => "easy",
            Difficulty::Medium => "medium",
            Difficulty::Hard => "hard",
        };
        diesel::serialize::ToSql::<diesel::sql_types::Text, DB>::to_sql(s, out)
    }
}

impl<DB> diesel::deserialize::FromSql<diesel::sql_types::Text, DB> for Difficulty
where
    DB: diesel::backend::Backend,
    String: diesel::deserialize::FromSql<diesel::sql_types::Text, DB>,
{
    fn from_sql(bytes: DB::RawValue<'_>) -> diesel::deserialize::Result<Self> {
        let s = String::from_sql(bytes)?;
        match s.as_str() {
            "easy" => Ok(Difficulty::Easy),
            "medium" => Ok(Difficulty::Medium),
            "hard" => Ok(Difficulty::Hard),
            _ => Err("Invalid difficulty".into()),
        }
    }
}
