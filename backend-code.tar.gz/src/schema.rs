table! {
    activation_codes (id) {
        id -> Int4,
        code -> Varchar,
        valid_until -> Timestamp,
        used_by -> Nullable<Int4>,
        status -> Text,
        created_at -> Timestamp,
        updated_at -> Timestamp,
    }
}

table! {
    exam_sessions (id) {
        id -> Int4,
        paper_id -> Int4,
        title -> Varchar,
        start_time -> Timestamp,
        end_time -> Timestamp,
        created_by -> Int4,
        status -> Text,
        created_at -> Timestamp,
        updated_at -> Timestamp,
    }
}

table! {
    points_records (id) {
        id -> Int4,
        student_id -> Int4,
        points -> Int4,
        reason -> Varchar,
        related_id -> Nullable<Int4>,
        related_type -> Nullable<Text>,
        created_at -> Timestamp,
    }
}

table! {
    papers (id) {
        id -> Int4,
        title -> Varchar,
        subject_id -> Int4,
        created_by -> Int4,
        total_score -> Int4,
        duration -> Int4,
        paper_type -> Text,
        status -> Text,
        created_at -> Timestamp,
        updated_at -> Timestamp,
    }
}

table! {
    question_banks (id) {
        id -> Int4,
        name -> Varchar,
        subject_id -> Int4,
        description -> Nullable<Varchar>,
        created_by -> Int4,
        created_at -> Timestamp,
        updated_at -> Timestamp,
    }
}

table! {
    questions (id) {
        id -> Int4,
        paper_id -> Nullable<Int4>,
        question_bank_id -> Nullable<Int4>,
        question_type -> Text,
        content -> Text,
        image_url -> Nullable<Varchar>,
        options -> Nullable<Jsonb>,
        correct_answer -> Text,
        score -> Int4,
        difficulty -> Text,
        knowledge_point -> Nullable<Varchar>,
        created_at -> Timestamp,
        updated_at -> Timestamp,
    }
}

table! {
    scores (id) {
        id -> Int4,
        exam_session_id -> Int4,
        student_id -> Int4,
        total_score -> Int4,
        objective_score -> Int4,
        subjective_score -> Int4,
        is_graded -> Bool,
        graded_by -> Nullable<Int4>,
        graded_at -> Nullable<Timestamp>,
        created_at -> Timestamp,
        updated_at -> Timestamp,
    }
}

table! {
    users (id) {
        id -> Int4,
        username -> Varchar,
        email -> Nullable<Varchar>,
        phone -> Nullable<Varchar>,
        password_hash -> Varchar,
        user_type -> Text,
        status -> Text,
        created_at -> Timestamp,
        updated_at -> Timestamp,
    }
}

joinable!(exam_sessions -> papers (paper_id));
joinable!(points_records -> users (student_id));
joinable!(papers -> users (created_by));
joinable!(question_banks -> users (created_by));
joinable!(questions -> papers (paper_id));
joinable!(questions -> question_banks (question_bank_id));
joinable!(scores -> exam_sessions (exam_session_id));
joinable!(scores -> users (student_id));

allow_tables_to_appear_in_same_query! {
    activation_codes,
    exam_sessions,
    points_records,
    papers,
    question_banks,
    questions,
    scores,
    users,
}
