use rusqlite::{Connection, Result, Row};
use std::env;
use std::path::Path;
use chrono::{NaiveDateTime, Utc};
use uuid::Uuid;

use crate::model::user::{User, UserType, UserStatus, NewUser, UpdateUser};

/// 初始化数据库连接
pub fn init_pool() -> Result<Connection> {
    // 获取数据库URL，如果是SQLite则解析为文件路径
    let database_url = env::var("DATABASE_URL").unwrap_or("sqlite://./teaching_software.db".to_string());
    
    // 解析数据库URL，提取SQLite文件路径
    let db_path = if database_url.starts_with("sqlite://") {
        database_url.trim_start_matches("sqlite://")
    } else {
        database_url.as_str()
    };
    
    // 确保数据库文件所在目录存在
    if let Some(parent_dir) = Path::new(db_path).parent() {
        std::fs::create_dir_all(parent_dir)?;
    }
    
    // 打开数据库连接
    let conn = Connection::open(db_path)?;
    
    Ok(conn)
}

/// 运行数据库迁移
pub fn run_migrations(conn: &Connection) -> Result<()> {
    // 创建用户表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            user_type TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    // 创建激活码表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS activation_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            used_by INTEGER REFERENCES users(id),
            expires_at TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    // 创建试卷表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS papers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            creator_id INTEGER REFERENCES users(id),
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    // 创建题目表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            paper_id INTEGER REFERENCES papers(id),
            content TEXT NOT NULL,
            question_type TEXT NOT NULL,
            options TEXT,
            answer TEXT NOT NULL,
            score INTEGER NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    // 创建考试会话表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS exam_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            paper_id INTEGER REFERENCES papers(id),
            student_id INTEGER REFERENCES users(id),
            start_time TEXT NOT NULL,
            end_time TEXT,
            status TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    // 创建成绩表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_session_id INTEGER REFERENCES exam_sessions(id),
            total_score INTEGER NOT NULL,
            detailed_scores TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    // 创建题库表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS question_bank (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            creator_id INTEGER REFERENCES users(id),
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    // 创建积分记录表
    conn.execute(
        "CREATE TABLE IF NOT EXISTS points_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER REFERENCES users(id),
            points INTEGER NOT NULL,
            reason TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )",
        (),
    )?;
    
    Ok(())
}

/// 获取数据库连接（直接返回连接，因为Rusqlite使用单连接）
pub fn get_conn(conn: &Connection) -> Result<&Connection> {
    Ok(conn)
}

// 用户相关数据库操作

/// 从Row中解析User
fn parse_user(row: &Row) -> Result<User> {
    Ok(User {
        id: row.get("id")?,
        username: row.get("username")?,
        email: row.get("email")?,
        phone: row.get("phone")?,
        password_hash: row.get("password_hash")?,
        user_type: UserType::from(row.get::<_, String>("user_type")?.as_str()),
        status: UserStatus::from(row.get::<_, String>("status")?.as_str()),
        created_at: NaiveDateTime::parse_from_str(&row.get::<_, String>("created_at")?, "%Y-%m-%d %H:%M:%S")?,
        updated_at: NaiveDateTime::parse_from_str(&row.get::<_, String>("updated_at")?, "%Y-%m-%d %H:%M:%S")?,
    })
}

/// 创建用户
pub fn create_user(conn: &Connection, new_user: &NewUser) -> Result<User> {
    let now = Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();
    
    conn.execute(
        "INSERT INTO users (username, password_hash, email, phone, user_type, status, created_at, updated_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (new_user.username, new_user.password_hash, new_user.email, new_user.phone, 
         new_user.user_type.to_string(), new_user.status.to_string(), now, now),
    )?;
    
    let user_id = conn.last_insert_rowid() as i32;
    get_user_by_id(conn, user_id)
}

/// 根据ID获取用户
pub fn get_user_by_id(conn: &Connection, user_id: i32) -> Result<User> {
    let mut stmt = conn.prepare("SELECT * FROM users WHERE id = ?")?;
    let user = stmt.query_row([user_id], |row| parse_user(row))?;
    Ok(user)
}

/// 根据用户名获取用户
pub fn get_user_by_username(conn: &Connection, username: &str) -> Result<Option<User>> {
    let mut stmt = conn.prepare("SELECT * FROM users WHERE username = ?")?;
    let user = stmt.query_row([username], |row| parse_user(row)).optional()?;
    Ok(user)
}

/// 更新用户信息
pub fn update_user(conn: &Connection, user_id: i32, update_user: &UpdateUser) -> Result<User> {
    let now = Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();
    
    let current_user = get_user_by_id(conn, user_id)?;
    
    let username = update_user.username.as_ref().unwrap_or(&current_user.username);
    let password_hash = update_user.password_hash.as_ref().unwrap_or(&current_user.password_hash);
    let email = update_user.email.as_ref().unwrap_or(&current_user.email);
    let phone = update_user.phone.as_ref().unwrap_or(&current_user.phone);
    let user_type = update_user.user_type.unwrap_or(current_user.user_type);
    let status = update_user.status.unwrap_or(current_user.status);
    
    conn.execute(
        "UPDATE users SET username = ?, password_hash = ?, email = ?, phone = ?, 
         user_type = ?, status = ?, updated_at = ? WHERE id = ?",
        (username, password_hash, email, phone, user_type.to_string(), status.to_string(), now, user_id),
    )?;
    
    get_user_by_id(conn, user_id)
}

/// 删除用户
pub fn delete_user(conn: &Connection, user_id: i32) -> Result<()> {
    conn.execute("DELETE FROM users WHERE id = ?", [user_id])?;
    Ok(())
}

/// 获取所有用户
pub fn get_all_users(conn: &Connection) -> Result<Vec<User>> {
    let mut stmt = conn.prepare("SELECT * FROM users")?;
    let user_iter = stmt.query_map([], |row| parse_user(row))?;
    
    let mut users = Vec::new();
    for user in user_iter {
        users.push(user?);
    }
    
    Ok(users)
}

// 激活码相关数据库操作

/// 生成激活码
pub fn generate_activation_code(conn: &Connection, expires_at: &NaiveDateTime) -> Result<String> {
    let code = Uuid::new_v4().to_string();
    let expires_str = expires_at.format("%Y-%m-%d %H:%M:%S").to_string();
    
    conn.execute(
        "INSERT INTO activation_codes (code, expires_at) VALUES (?, ?)",
        (code, expires_str),
    )?;
    
    Ok(code)
}

/// 根据代码获取激活码
pub fn get_activation_code(conn: &Connection, code: &str) -> Result<Option<(i32, String, Option<i32>, String)>> {
    let mut stmt = conn.prepare("SELECT id, code, used_by, expires_at FROM activation_codes WHERE code = ?")?;
    let result = stmt.query_row([code], |row| {
        Ok((
            row.get("id")?,
            row.get("code")?,
            row.get("used_by")?,
            row.get("expires_at")?,
        ))
    }).optional()?;
    
    Ok(result)
}

/// 使用激活码
pub fn use_activation_code(conn: &Connection, code: &str, user_id: i32) -> Result<()> {
    conn.execute(
        "UPDATE activation_codes SET used_by = ? WHERE code = ?",
        (user_id, code),
    )?;
    Ok(())
}

/// 获取所有激活码
pub fn get_all_activation_codes(conn: &Connection) -> Result<Vec<(i32, String, Option<i32>, String, String)>> {
    let mut stmt = conn.prepare("SELECT id, code, used_by, expires_at, created_at FROM activation_codes")?;
    let code_iter = stmt.query_map([], |row| {
        Ok((
            row.get("id")?,
            row.get("code")?,
            row.get("used_by")?,
            row.get("expires_at")?,
            row.get("created_at")?,
        ))
    })?;
    
    let mut codes = Vec::new();
    for code in code_iter {
        codes.push(code?);
    }
    
    Ok(codes)
}

/// 删除激活码
pub fn delete_activation_code(conn: &Connection, code_id: i32) -> Result<()> {
    conn.execute("DELETE FROM activation_codes WHERE id = ?", [code_id])?;
    Ok(())
}
