use axum::{extract::Json, http::StatusCode, Extension};
use serde::{Deserialize, Serialize};
use chrono::{NaiveDateTime, Utc};

use crate::db::{self, Connection};
use crate::model::user::{NewUser, User, UserStatus, UserType};
use crate::utils::password::{hash_password, verify_password};

#[derive(Debug, Serialize, Deserialize)]
pub struct LoginRequest {
    pub username: String,
    pub password: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct RegisterRequest {
    pub username: String,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub password: String,
    pub user_type: UserType,
    pub activation_code: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ForgotPasswordRequest {
    pub email: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ResetPasswordRequest {
    pub email: String,
    pub token: String,
    pub new_password: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct TokenRefreshRequest {
    pub refresh_token: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AuthResponse {
    pub access_token: String,
    pub refresh_token: String,
    pub user: User,
}

// 登录处理
pub async fn login(
    Json(login_req): Json<LoginRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<AuthResponse>), (StatusCode, String)> {
    // 查找用户
    let user = db::get_user_by_username(&conn, &login_req.username)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to query user".to_string()))?;
    
    let user = match user {
        Some(user) => user,
        None => return Err((StatusCode::UNAUTHORIZED, "Invalid username or password".to_string())),
    };
    
    // 验证密码
    if !verify_password(&login_req.password, &user.password_hash) {
        return Err((StatusCode::UNAUTHORIZED, "Invalid username or password".to_string()));
    }
    
    // 生成Token
    let auth_response = generate_auth_response(user)?;
    
    Ok((StatusCode::OK, Json(auth_response)))
}

// 注册处理
pub async fn register(
    Json(register_req): Json<RegisterRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<AuthResponse>), (StatusCode, String)> {
    // 检查激活码（如果需要）
    if register_req.user_type != UserType::Student {
        if let Some(code) = &register_req.activation_code {
            let activation_code = db::get_activation_code(&conn, code)
                .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to check activation code".to_string()))?;
            
            if let Some((_, _, used_by, expires_at)) = activation_code {
                // 检查激活码是否已使用
                if used_by.is_some() {
                    return Err((StatusCode::BAD_REQUEST, "Activation code has been used".to_string()));
                }
                
                // 检查激活码是否过期
                let expires_at = NaiveDateTime::parse_from_str(&expires_at, "%Y-%m-%d %H:%M:%S")
                    .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Invalid activation code format".to_string()))?;
                
                if expires_at < Utc::now().naive_utc() {
                    return Err((StatusCode::BAD_REQUEST, "Activation code has expired".to_string()));
                }
            } else {
                return Err((StatusCode::BAD_REQUEST, "Invalid activation code".to_string()));
            }
        } else {
            return Err((StatusCode::BAD_REQUEST, "Activation code is required for this user type".to_string()));
        }
    }
    
    // 检查用户名是否已存在
    if let Some(_) = db::get_user_by_username(&conn, &register_req.username)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to check username".to_string()))? {
        return Err((StatusCode::BAD_REQUEST, "Username already exists".to_string()));
    }
    
    // 哈希密码
    let password_hash = hash_password(&register_req.password)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to hash password".to_string()))?;
    
    // 创建新用户
    let new_user = NewUser {
        username: register_req.username,
        email: register_req.email,
        phone: register_req.phone,
        password_hash,
        user_type: register_req.user_type,
        status: UserStatus::Active,
    };
    
    let user = db::create_user(&conn, &new_user)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create user".to_string()))?;
    
    // 如果使用了激活码，标记为已使用
    if let Some(code) = register_req.activation_code {
        db::use_activation_code(&conn, &code, user.id)
            .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to use activation code".to_string()))?;
    }
    
    // 生成Token
    let auth_response = generate_auth_response(user)?;
    
    Ok((StatusCode::OK, Json(auth_response)))
}

// 忘记密码处理
pub async fn forgot_password(
    Json(_forgot_req): Json<ForgotPasswordRequest>,
    Extension(_conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // TODO: 实现忘记密码逻辑
    Ok((StatusCode::OK, "Password reset email sent".to_string()))
}

// 重置密码处理
pub async fn reset_password(
    Json(_reset_req): Json<ResetPasswordRequest>,
    Extension(_conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // TODO: 实现重置密码逻辑
    Ok((StatusCode::OK, "Password reset successfully".to_string()))
}

// 刷新Token处理
pub async fn refresh(
    Json(_refresh_req): Json<TokenRefreshRequest>,
    Extension(_conn): Extension<Connection>,
) -> Result<(StatusCode, Json<AuthResponse>), (StatusCode, String)> {
    // TODO: 实现刷新Token逻辑
    Ok((StatusCode::OK, Json(AuthResponse {
        access_token: "".to_string(),
        refresh_token: "".to_string(),
        user: User {
            id: 0,
            username: "".to_string(),
            email: None,
            phone: None,
            password_hash: "".to_string(),
            user_type: UserType::Student,
            status: UserStatus::Active,
            created_at: Utc::now().naive_utc(),
            updated_at: Utc::now().naive_utc(),
        },
    })))
}

// 生成认证响应
fn generate_auth_response(user: User) -> Result<AuthResponse, (StatusCode, String)> {
    let access_token = crate::utils::jwt::generate_token(user.id, user.user_type)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e))?;
    
    let refresh_token = crate::utils::jwt::generate_refresh_token(user.id, user.user_type)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e))?;
    
    Ok(AuthResponse {
        access_token,
        refresh_token,
        user,
    })
}
