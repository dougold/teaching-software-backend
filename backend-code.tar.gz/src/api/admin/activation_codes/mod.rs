use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use chrono::{Duration, Local};
use diesel::prelude::*;
use rand::distributions::Alphanumeric;
use rand::{thread_rng, Rng};
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::activation_code::{NewActivationCode, UpdateActivationCode, ActivationCode, ActivationStatus};

#[derive(Debug, Deserialize)]
pub struct ActivationCodeQuery {
    pub status: Option<ActivationStatus>,
    pub page: Option<i32>,
    pub limit: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GenerateCodeRequest {
    pub count: Option<i32>,
    pub valid_days: Option<i32>,
}

#[derive(Debug, Serialize)]
pub struct ActivationCodeListResponse {
    pub total: i64,
    pub codes: Vec<ActivationCode>,
}

// 生成激活码
pub async fn generate_code(
    Json(generate_req): Json<GenerateCodeRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<Vec<ActivationCode>>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let count = generate_req.count.unwrap_or(1);
    let valid_days = generate_req.valid_days.unwrap_or(30);
    let valid_until = Local::now().naive_local() + Duration::days(valid_days as i64);
    
    let mut codes = Vec::new();
    
    for _ in 0..count {
        // 生成随机激活码
        let code: String = thread_rng()
            .sample_iter(&Alphanumeric)
            .take(16)
            .map(char::from)
            .collect();
        
        let new_code = NewActivationCode {
            code,
            valid_until,
            status: ActivationStatus::Unused,
        };
        
        let activation_code = diesel::insert_into(crate::schema::activation_codes::table)
            .values(&new_code)
            .returning(ActivationCode::as_returning())
            .get_result(&conn)
            .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to generate activation code".to_string()))?;
        
        codes.push(activation_code);
    }
    
    Ok((StatusCode::CREATED, Json(codes)))
}

// 获取激活码列表
pub async fn get_codes(
    Query(query): Query<ActivationCodeQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ActivationCodeListResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let mut query_builder = ActivationCode::table.into_boxed();
    
    // 应用过滤条件
    if let Some(status) = query.status {
        query_builder = query_builder.filter(crate::schema::activation_codes::status.eq(status));
    }
    
    // 计算总数
    let total = query_builder.count().get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count activation codes".to_string()))?;
    
    // 分页
    let page = query.page.unwrap_or(1);
    let limit = query.limit.unwrap_or(10);
    let offset = (page - 1) * limit;
    
    let codes = query_builder
        .offset(offset)
        .limit(limit)
        .load::<ActivationCode>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch activation codes".to_string()))?;
    
    Ok((StatusCode::OK, Json(ActivationCodeListResponse {
        total,
        codes,
    })))
}

// 删除激活码
pub async fn delete_code(
    Path(code_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 检查激活码是否存在
    if ActivationCode::table
        .find(code_id)
        .first::<ActivationCode>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find activation code".to_string()))?
        .is_none()
    {
        return Err((StatusCode::NOT_FOUND, "Activation code not found".to_string()));
    }
    
    diesel::delete(ActivationCode::table.find(code_id))
        .execute(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to delete activation code".to_string()))?;
    
    Ok((StatusCode::OK, "Activation code deleted successfully".to_string()))
}
