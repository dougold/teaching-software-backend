use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::user::{NewUser, UpdateUser, User, UserStatus, UserType};
use crate::utils::password::hash_password;

#[derive(Debug, Deserialize)]
pub struct UserQuery {
    pub user_type: Option<UserType>,
    pub status: Option<UserStatus>,
    pub page: Option<i32>,
    pub limit: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateUserRequest {
    pub username: String,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub password: String,
    pub user_type: UserType,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdateUserRequest {
    pub username: Option<String>,
    pub email: Option<Option<String>>,
    pub phone: Option<Option<String>>,
    pub password: Option<String>,
    pub user_type: Option<UserType>,
    pub status: Option<UserStatus>,
}

#[derive(Debug, Serialize)]
pub struct UserListResponse {
    pub total: i64,
    pub users: Vec<User>,
}

// 获取用户列表
pub async fn get_users(
    Query(query): Query<UserQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<UserListResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let mut query_builder = User::table.into_boxed();
    
    // 应用过滤条件
    if let Some(user_type) = query.user_type {
        query_builder = query_builder.filter(crate::schema::users::user_type.eq(user_type));
    }
    
    if let Some(status) = query.status {
        query_builder = query_builder.filter(crate::schema::users::status.eq(status));
    }
    
    // 计算总数
    let total = query_builder.count().get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count users".to_string()))?;
    
    // 分页
    let page = query.page.unwrap_or(1);
    let limit = query.limit.unwrap_or(10);
    let offset = (page - 1) * limit;
    
    let users = query_builder
        .offset(offset)
        .limit(limit)
        .load::<User>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch users".to_string()))?;
    
    Ok((StatusCode::OK, Json(UserListResponse {
        total,
        users,
    })))
}

// 创建用户
pub async fn create_user(
    Json(create_req): Json<CreateUserRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<User>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 检查用户名是否已存在
    if User::table
        .filter(crate::schema::users::username.eq(&create_req.username))
        .first::<User>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to check username".to_string()))?
        .is_some()
    {
        return Err((StatusCode::BAD_REQUEST, "Username already exists".to_string()));
    }
    
    // 哈希密码
    let password_hash = hash_password(&create_req.password)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to hash password".to_string()))?;
    
    let new_user = NewUser {
        username: create_req.username,
        email: create_req.email,
        phone: create_req.phone,
        password_hash,
        user_type: create_req.user_type,
        status: UserStatus::Active,
    };
    
    let user = diesel::insert_into(crate::schema::users::table)
        .values(&new_user)
        .returning(User::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create user".to_string()))?;
    
    Ok((StatusCode::CREATED, Json(user)))
}

// 更新用户
pub async fn update_user(
    Path(user_id): Path<i32>,
    Json(update_req): Json<UpdateUserRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<User>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 检查用户是否存在
    let existing_user = User::table
        .find(user_id)
        .first::<User>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find user".to_string()))?;
    
    let existing_user = match existing_user {
        Some(user) => user,
        None => return Err((StatusCode::NOT_FOUND, "User not found".to_string())),
    };
    
    // 准备更新数据
    let mut update_data = UpdateUser {
        username: update_req.username,
        email: update_req.email,
        phone: update_req.phone,
        user_type: update_req.user_type,
        status: update_req.status,
        password_hash: None,
    };
    
    // 如果提供了新密码，哈希处理
    if let Some(new_password) = update_req.password {
        update_data.password_hash = Some(hash_password(&new_password)
            .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to hash password".to_string()))?);
    }
    
    let updated_user = diesel::update(User::table.find(user_id))
        .set(&update_data)
        .returning(User::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to update user".to_string()))?;
    
    Ok((StatusCode::OK, Json(updated_user)))
}

// 删除用户
pub async fn delete_user(
    Path(user_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 检查用户是否存在
    if User::table
        .find(user_id)
        .first::<User>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find user".to_string()))?
        .is_none()
    {
        return Err((StatusCode::NOT_FOUND, "User not found".to_string()));
    }
    
    diesel::delete(User::table.find(user_id))
        .execute(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to delete user".to_string()))?;
    
    Ok((StatusCode::OK, "User deleted successfully".to_string()))
}
