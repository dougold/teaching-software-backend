use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};
use chrono::{Duration, Utc};

use crate::db::{self, Connection};

#[derive(Debug, Serialize, Deserialize)]
pub struct GenerateCodeRequest {
    pub duration_days: i64, // 激活码有效期（天）
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ActivationCodeResponse {
    pub id: i32,
    pub code: String,
    pub used_by: Option<i32>,
    pub expires_at: String,
    pub created_at: String,
}

// 生成激活码
pub async fn generate_code(
    Json(generate_req): Json<GenerateCodeRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<ActivationCodeResponse>), (StatusCode, String)> {
    // 计算过期时间
    let expires_at = Utc::now() + Duration::days(generate_req.duration_days);
    
    // 生成激活码
    let code = db::generate_activation_code(&conn, &expires_at)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to generate activation code".to_string()))?;
    
    // 获取刚生成的激活码信息
    let activation_code = db::get_activation_code(&conn, &code)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get activation code".to_string()))?;
    
    if let Some((id, code, used_by, expires_at_str)) = activation_code {
        // 获取创建时间
        let codes = db::get_all_activation_codes(&conn)
            .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get activation codes".to_string()))?;
        
        let created_at = codes.iter()
            .find(|(code_id, _, _, _, _)| *code_id == id)
            .map(|(_, _, _, _, created_at)| created_at.to_string())
            .unwrap_or(Utc::now().format("%Y-%m-%d %H:%M:%S").to_string());
        
        let response = ActivationCodeResponse {
            id,
            code,
            used_by,
            expires_at: expires_at_str,
            created_at,
        };
        
        Ok((StatusCode::CREATED, Json(response)))
    } else {
        Err((StatusCode::INTERNAL_SERVER_ERROR, "Failed to get generated activation code".to_string()))
    }
}

// 获取所有激活码
pub async fn get_codes(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Vec<ActivationCodeResponse>>), (StatusCode, String)> {
    let codes = db::get_all_activation_codes(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get activation codes".to_string()))?;
    
    let response = codes.into_iter().map(|(id, code, used_by, expires_at, created_at)| {
        ActivationCodeResponse {
            id,
            code,
            used_by,
            expires_at,
            created_at,
        }
    }).collect();
    
    Ok((StatusCode::OK, Json(response)))
}

// 删除激活码
pub async fn delete_code(
    Path(code_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // 删除激活码
    db::delete_activation_code(&conn, code_id)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to delete activation code".to_string()))?;
    
    Ok((StatusCode::OK, "Activation code deleted successfully".to_string()))
}