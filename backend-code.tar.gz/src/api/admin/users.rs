use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};

use crate::db::{self, Connection};
use crate::model::user::{NewUser, UpdateUser, User, UserStatus, UserType};
use crate::utils::password::hash_password;

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateUserRequest {
    pub username: String,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub password: String,
    pub user_type: UserType,
    pub status: UserStatus,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdateUserRequest {
    pub username: Option<String>,
    pub email: Option<Option<String>>,
    pub phone: Option<Option<String>>,
    pub password: Option<String>,
    pub user_type: Option<UserType>,
    pub status: Option<UserStatus>,
}

// 获取所有用户
pub async fn get_users(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Vec<User>>), (StatusCode, String)> {
    let users = db::get_all_users(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get users".to_string()))?;
    
    Ok((StatusCode::OK, Json(users)))
}

// 创建用户
pub async fn create_user(
    Json(create_req): Json<CreateUserRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<User>), (StatusCode, String)> {
    // 检查用户名是否已存在
    if let Some(_) = db::get_user_by_username(&conn, &create_req.username)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to check username".to_string()))? {
        return Err((StatusCode::BAD_REQUEST, "Username already exists".to_string()));
    }
    
    // 哈希密码
    let password_hash = hash_password(&create_req.password)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to hash password".to_string()))?;
    
    // 创建新用户
    let new_user = NewUser {
        username: create_req.username,
        email: create_req.email,
        phone: create_req.phone,
        password_hash,
        user_type: create_req.user_type,
        status: create_req.status,
    };
    
    let user = db::create_user(&conn, &new_user)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create user".to_string()))?;
    
    Ok((StatusCode::CREATED, Json(user)))
}

// 更新用户
pub async fn update_user(
    Path(user_id): Path<i32>,
    Json(update_req): Json<UpdateUserRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<User>), (StatusCode, String)> {
    // 检查用户是否存在
    let _ = db::get_user_by_id(&conn, user_id)
        .map_err(|_| (StatusCode::NOT_FOUND, "User not found".to_string()))?;
    
    // 处理密码哈希
    let password_hash = if let Some(password) = update_req.password {
        Some(hash_password(&password)
            .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to hash password".to_string()))?)
    } else {
        None
    };
    
    // 创建更新用户请求
    let update_user = UpdateUser {
        username: update_req.username,
        email: update_req.email,
        phone: update_req.phone,
        password_hash,
        user_type: update_req.user_type,
        status: update_req.status,
    };
    
    let user = db::update_user(&conn, user_id, &update_user)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to update user".to_string()))?;
    
    Ok((StatusCode::OK, Json(user)))
}

// 删除用户
pub async fn delete_user(
    Path(user_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // 检查用户是否存在
    let _ = db::get_user_by_id(&conn, user_id)
        .map_err(|_| (StatusCode::NOT_FOUND, "User not found".to_string()))?;
    
    // 删除用户
    db::delete_user(&conn, user_id)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to delete user".to_string()))?;
    
    Ok((StatusCode::OK, "User deleted successfully".to_string()))
}