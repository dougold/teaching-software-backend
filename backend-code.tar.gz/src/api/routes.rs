use axum::{routing::*, Router};

pub fn create_routes() -> Router {
    Router::new()
        .nest("/auth", auth_routes())
        .nest("/admin", admin_routes())
        .nest("/teacher", teacher_routes())
        .nest("/student", student_routes())
}

fn auth_routes() -> Router {
    Router::new()
        .route("/login", post(crate::api::auth::login))
        .route("/register", post(crate::api::auth::register))
        .route("/forgot-password", post(crate::api::auth::forgot_password))
        .route("/reset-password", post(crate::api::auth::reset_password))
        .route("/refresh", post(crate::api::auth::refresh))
}

fn admin_routes() -> Router {
    Router::new()
        .route("/users", get(crate::api::admin::users::get_users))
        .route("/users", post(crate::api::admin::users::create_user))
        .route("/users/:id", put(crate::api::admin::users::update_user))
        .route("/users/:id", delete(crate::api::admin::users::delete_user))
        .route("/activation-codes", post(crate::api::admin::activation_codes::generate_code))
        .route("/activation-codes", get(crate::api::admin::activation_codes::get_codes))
        .route("/activation-codes/:id", delete(crate::api::admin::activation_codes::delete_code))
}

fn teacher_routes() -> Router {
    Router::new()
        .route("/papers/import", post(crate::api::teacher::papers::import_paper))
        .route("/papers", get(crate::api::teacher::papers::get_papers))
        .route("/papers", post(crate::api::teacher::papers::create_paper))
        .route("/papers/:id", get(crate::api::teacher::papers::get_paper))
        .route("/papers/:id", put(crate::api::teacher::papers::update_paper))
        .route("/papers/:id", delete(crate::api::teacher::papers::delete_paper))
        .route("/exams", post(crate::api::teacher::exams::create_exam))
        .route("/exams", get(crate::api::teacher::exams::get_exams))
        .route("/exams/:id/monitor", get(crate::api::teacher::exams::monitor_exam))
        .route("/exams/:id/auto-correct", post(crate::api::teacher::exams::auto_correct))
        .route("/exams/:id/analysis", get(crate::api::teacher::exams::analysis))
        .route("/question-banks", get(crate::api::teacher::question_banks::get_banks))
        .route("/question-banks", post(crate::api::teacher::question_banks::create_bank))
        .route("/question-banks/generate", post(crate::api::teacher::question_banks::generate_paper))
}

fn student_routes() -> Router {
    Router::new()
        .route("/exams", get(crate::api::student::exams::get_available_exams))
        .route("/exams/:id", get(crate::api::student::exams::get_exam_detail))
        .route("/exams/:id/submit", post(crate::api::student::exams::submit_answer))
        .route("/scores", get(crate::api::student::scores::get_scores))
        .route("/scores/:id", get(crate::api::student::scores::get_score_detail))
        .route("/practice/ai", post(crate::api::student::practice::ai_practice))
        .route("/points", get(crate::api::student::points::get_points))
        .route("/points/records", get(crate::api::student::points::get_points_records))
}
