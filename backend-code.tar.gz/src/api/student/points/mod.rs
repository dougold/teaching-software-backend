use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::points_record::{PointsRecord, NewPointsRecord};

#[derive(Debug, Deserialize)]
pub struct PointsRecordQuery {
    pub limit: Option<i32>,
    pub offset: Option<i32>,
}

#[derive(Debug, Serialize)]
pub struct PointsInfoResponse {
    pub total_points: i32,
    pub current_level: i32,
    pub next_level_points: i32,
    pub points_to_next_level: i32,
    pub unlocked_features: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct PointsRecordResponse {
    pub total: i64,
    pub records: Vec<PointsRecord>,
}

// 获取积分信息
pub async fn get_points(
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<PointsInfoResponse>), (StatusCode, String)> {
    // TODO: 获取当前学生ID
    let student_id = 1; // 临时使用固定ID
    
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 计算总积分
    let total_points = PointsRecord::table
        .filter(crate::schema::points_records::student_id.eq(student_id))
        .select(diesel::dsl::sum(crate::schema::points_records::points))
        .get_result::<Option<i32>>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to calculate total points".to_string()))?
        .unwrap_or(0);
    
    // 计算当前等级（简单的等级计算逻辑：每100积分升一级）
    let current_level = (total_points / 100) + 1;
    let next_level_points = current_level * 100;
    let points_to_next_level = next_level_points - total_points;
    
    // 计算解锁的功能
    let mut unlocked_features = Vec::new();
    if current_level >= 1 {
        unlocked_features.push("基础练习".to_string());
    }
    if current_level >= 2 {
        unlocked_features.push("AI针对性练习".to_string());
    }
    if current_level >= 3 {
        unlocked_features.push("模拟考试".to_string());
    }
    if current_level >= 5 {
        unlocked_features.push("知识点解析".to_string());
    }
    if current_level >= 10 {
        unlocked_features.push("专家指导".to_string());
    }
    
    Ok((StatusCode::OK, Json(PointsInfoResponse {
        total_points,
        current_level,
        next_level_points,
        points_to_next_level,
        unlocked_features,
    })))
}

// 获取积分记录
pub async fn get_points_records(
    Query(query): Query<PointsRecordQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<PointsRecordResponse>), (StatusCode, String)> {
    // TODO: 获取当前学生ID
    let student_id = 1; // 临时使用固定ID
    
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let limit = query.limit.unwrap_or(20);
    let offset = query.offset.unwrap_or(0);
    
    // 计算总数
    let total = PointsRecord::table
        .filter(crate::schema::points_records::student_id.eq(student_id))
        .count()
        .get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count points records".to_string()))?;
    
    // 获取积分记录
    let records = PointsRecord::table
        .filter(crate::schema::points_records::student_id.eq(student_id))
        .order(crate::schema::points_records::created_at.desc())
        .limit(limit)
        .offset(offset)
        .load::<PointsRecord>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch points records".to_string()))?;
    
    Ok((StatusCode::OK, Json(PointsRecordResponse {
        total,
        records,
    })))
}
