use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};
use chrono::{Utc};

use crate::db::{self, Connection};

#[derive(Debug, Serialize, Deserialize)]
pub struct Exam {
    pub id: i32,
    pub paper_id: i32,
    pub title: String,
    pub description: Option<String>,
    pub start_time: String,
    pub end_time: Option<String>,
    pub status: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ExamDetail {
    pub id: i32,
    pub paper_id: i32,
    pub title: String,
    pub description: Option<String>,
    pub questions: Vec<Question>,
    pub start_time: String,
    pub end_time: Option<String>,
    pub status: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Question {
    pub id: i32,
    pub paper_id: i32,
    pub content: String,
    pub question_type: String,
    pub options: Option<String>,
    pub score: i32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SubmitAnswerRequest {
    pub answers: Vec<Answer>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Answer {
    pub question_id: i32,
    pub answer: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SubmitAnswerResponse {
    pub status: String,
    pub message: String,
    pub exam_id: i32,
}

// 获取可用考试列表
pub async fn get_available_exams(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Vec<Exam>>), (StatusCode, String)> {
    // TODO: 实现获取可用考试列表逻辑
    Ok((StatusCode::OK, Json(Vec::new())))
}

// 获取考试详情
pub async fn get_exam_detail(
    Path(exam_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<ExamDetail>), (StatusCode, String)> {
    // TODO: 实现获取考试详情逻辑
    let exam = ExamDetail {
        id: exam_id,
        paper_id: 1,
        title: "Test Exam".to_string(),
        description: Some("This is a test exam".to_string()),
        questions: Vec::new(),
        start_time: Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
        end_time: None,
        status: "active".to_string(),
    };
    
    Ok((StatusCode::OK, Json(exam)))
}

// 提交答案
pub async fn submit_answer(
    Path(exam_id): Path<i32>,
    Json(submit_req): Json<SubmitAnswerRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<SubmitAnswerResponse>), (StatusCode, String)> {
    // TODO: 实现提交答案逻辑
    let response = SubmitAnswerResponse {
        status: "success".to_string(),
        message: "Answer submitted successfully".to_string(),
        exam_id,
    };
    
    Ok((StatusCode::OK, Json(response)))
}