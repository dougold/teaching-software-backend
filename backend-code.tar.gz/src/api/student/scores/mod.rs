use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::exam_session::ExamSession;
use crate::model::paper::Paper;
use crate::model::score::Score;
use crate::model::question::Question;

#[derive(Debug, Deserialize)]
pub struct ScoreQuery {
    pub exam_session_id: Option<i32>,
    pub subject_id: Option<i32>,
    pub page: Option<i32>,
    pub limit: Option<i32>,
}

#[derive(Debug, Serialize)]
pub struct ScoreListResponse {
    pub total: i64,
    pub scores: Vec<ScoreWithExamInfo>,
}

#[derive(Debug, Serialize)]
pub struct ScoreDetailResponse {
    pub score: Score,
    pub exam: ExamSession,
    pub paper: Paper,
    pub questions: Vec<QuestionWithAnswer>,
}

#[derive(Debug, Serialize)]
pub struct ScoreWithExamInfo {
    pub score: Score,
    pub exam: ExamSession,
    pub paper: Paper,
}

#[derive(Debug, Serialize)]
pub struct QuestionWithAnswer {
    pub question: Question,
    pub student_answer: String,
    pub correct: bool,
    pub score: i32,
}

// 获取成绩列表
pub async fn get_scores(
    Query(query): Query<ScoreQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ScoreListResponse>), (StatusCode, String)> {
    // TODO: 获取当前学生ID
    let student_id = 1; // 临时使用固定ID
    
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 构建查询
    let mut query_builder = Score::table
        .inner_join(crate::schema::exam_sessions::table)
        .inner_join(crate::schema::papers::table)
        .filter(crate::schema::scores::student_id.eq(student_id))
        .select((Score::as_select(), ExamSession::as_select(), Paper::as_select()))
        .into_boxed();
    
    // 应用过滤条件
    if let Some(exam_session_id) = query.exam_session_id {
        query_builder = query_builder.filter(crate::schema::scores::exam_session_id.eq(exam_session_id));
    }
    
    if let Some(subject_id) = query.subject_id {
        query_builder = query_builder.filter(crate::schema::papers::subject_id.eq(subject_id));
    }
    
    // 计算总数
    let total = query_builder.clone()
        .count()
        .get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count scores".to_string()))?;
    
    // 分页
    let page = query.page.unwrap_or(1);
    let limit = query.limit.unwrap_or(10);
    let offset = (page - 1) * limit;
    
    let scores_with_info = query_builder
        .offset(offset)
        .limit(limit)
        .load::<(Score, ExamSession, Paper)>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch scores".to_string()))?;
    
    let scores = scores_with_info
        .into_iter()
        .map(|(score, exam, paper)| ScoreWithExamInfo {
            score,
            exam,
            paper,
        })
        .collect();
    
    Ok((StatusCode::OK, Json(ScoreListResponse {
        total,
        scores,
    })))
}

// 获取成绩详情
pub async fn get_score_detail(
    Path(score_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ScoreDetailResponse>), (StatusCode, String)> {
    // TODO: 获取当前学生ID
    let student_id = 1; // 临时使用固定ID
    
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 获取成绩信息
    let score = Score::table
        .find(score_id)
        .filter(crate::schema::scores::student_id.eq(student_id))
        .first::<Score>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find score".to_string()))?;
    
    let score = match score {
        Some(score) => score,
        None => return Err((StatusCode::NOT_FOUND, "Score not found".to_string())),
    };
    
    // 获取考试信息
    let exam = ExamSession::table
        .find(score.exam_session_id)
        .first::<ExamSession>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find exam".to_string()))?;
    
    // 获取试卷信息
    let paper = Paper::table
        .find(exam.paper_id)
        .first::<Paper>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find paper".to_string()))?;
    
    // TODO: 获取题目及学生答案信息
    let questions = Vec::new();
    
    Ok((StatusCode::OK, Json(ScoreDetailResponse {
        score,
        exam,
        paper,
        questions,
    })))
}
