use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};
use chrono::{Utc};

use crate::db::{self, Connection};

#[derive(Debug, Serialize, Deserialize)]
pub struct Score {
    pub id: i32,
    pub exam_session_id: i32,
    pub paper_title: String,
    pub total_score: i32,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ScoreDetail {
    pub id: i32,
    pub exam_session_id: i32,
    pub paper_title: String,
    pub paper_description: Option<String>,
    pub total_score: i32,
    pub detailed_scores: Vec<DetailedScore>,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DetailedScore {
    pub question_id: i32,
    pub question_content: String,
    pub question_type: String,
    pub student_answer: String,
    pub correct_answer: String,
    pub score: i32,
    pub max_score: i32,
}

// 获取成绩列表
pub async fn get_scores(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Vec<Score>>), (StatusCode, String)> {
    // TODO: 实现获取成绩列表逻辑
    Ok((StatusCode::OK, Json(Vec::new())))
}

// 获取成绩详情
pub async fn get_score_detail(
    Path(score_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<ScoreDetail>), (StatusCode, String)> {
    // TODO: 实现获取成绩详情逻辑
    let score = ScoreDetail {
        id: score_id,
        exam_session_id: score_id,
        paper_title: "Test Paper".to_string(),
        paper_description: Some("This is a test paper".to_string()),
        total_score: 0,
        detailed_scores: Vec::new(),
        status: "completed".to_string(),
        created_at: Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
    };
    
    Ok((StatusCode::OK, Json(score)))
}