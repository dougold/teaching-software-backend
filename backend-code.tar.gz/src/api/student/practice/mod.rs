use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::paper::{NewPaper, Paper, PaperType, PaperStatus};
use crate::model::question::{Question, QuestionType, Difficulty};

#[derive(Debug, Serialize, Deserialize)]
pub struct AIPracticeRequest {
    pub subject_id: i32,
    pub knowledge_points: Vec<String>,
    pub difficulty: Difficulty,
    pub question_count: Option<i32>,
    pub question_types: Option<Vec<QuestionType>>,
}

#[derive(Debug, Serialize)]
pub struct AIPracticeResponse {
    pub paper: Paper,
    pub questions: Vec<Question>,
    pub practice_id: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SubmitPracticeAnswerRequest {
    pub practice_id: String,
    pub answers: Vec<(i32, String)>, // (题目ID, 答案)
}

#[derive(Debug, Serialize)]
pub struct SubmitPracticeAnswerResponse {
    pub total_score: i32,
    pub correct_count: i32,
    pub incorrect_count: i32,
    pub question_results: Vec<QuestionResult>,
}

#[derive(Debug, Serialize)]
pub struct QuestionResult {
    pub question_id: i32,
    pub correct: bool,
    pub student_answer: String,
    pub correct_answer: String,
    pub score: i32,
}

// AI针对性练习
pub async fn ai_practice(
    Json(ai_practice_req): Json<AIPracticeRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<AIPracticeResponse>), (StatusCode, String)> {
    // TODO: 获取当前学生ID
    let student_id = 1; // 临时使用固定ID
    
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // TODO: 实现AI针对性练习逻辑
    // 1. 分析学生弱点
    // 2. 从题库中筛选适合的题目
    // 3. 生成练习试卷
    // 4. 返回练习内容
    
    // 创建练习试卷
    let new_paper = NewPaper {
        title: format!("AI针对性练习 - {}", ai_practice_req.subject_id),
        subject_id: ai_practice_req.subject_id,
        created_by: student_id,
        total_score: 100,
        duration: 60, // 60分钟
        paper_type: PaperType::Generated,
        status: PaperStatus::Draft,
    };
    
    let paper = diesel::insert_into(crate::schema::papers::table)
        .values(&new_paper)
        .returning(Paper::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create practice paper".to_string()))?;
    
    // TODO: 智能筛选题目
    let questions = Vec::new();
    let practice_id = format!("practice_{}_{}", student_id, paper.id);
    
    Ok((StatusCode::OK, Json(AIPracticeResponse {
        paper,
        questions,
        practice_id,
    })))
}
