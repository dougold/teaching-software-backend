use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};
use chrono::{Utc};

use crate::db::{self, Connection};

#[derive(Debug, Serialize, Deserialize)]
pub struct PointsResponse {
    pub total_points: i32,
    pub updated_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PointsRecord {
    pub id: i32,
    pub user_id: i32,
    pub points: i32,
    pub reason: String,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PointsRecordsResponse {
    pub records: Vec<PointsRecord>,
    pub total: i32,
    pub page: i32,
    pub page_size: i32,
}

// 获取积分
pub async fn get_points(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<PointsResponse>), (StatusCode, String)> {
    // TODO: 实现获取积分逻辑
    let response = PointsResponse {
        total_points: 0,
        updated_at: Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
    };
    
    Ok((StatusCode::OK, Json(response)))
}

// 获取积分记录
pub async fn get_points_records(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<PointsRecordsResponse>), (StatusCode, String)> {
    // TODO: 实现获取积分记录逻辑
    let response = PointsRecordsResponse {
        records: Vec::new(),
        total: 0,
        page: 1,
        page_size: 10,
    };
    
    Ok((StatusCode::OK, Json(response)))
}