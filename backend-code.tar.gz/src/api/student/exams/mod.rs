use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use chrono::Local;
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::exam_session::{ExamSession, ExamStatus};
use crate::model::paper::Paper;
use crate::model::question::Question;
use crate::model::score::{NewScore, Score};

#[derive(Debug, Deserialize)]
pub struct ExamQuery {
    pub status: Option<ExamStatus>,
    pub subject_id: Option<i32>,
    pub page: Option<i32>,
    pub limit: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SubmitAnswerRequest {
    pub exam_session_id: i32,
    pub answers: Vec<(i32, String)>, // (题目ID, 答案)
}

#[derive(Debug, Serialize)]
pub struct ExamListResponse {
    pub total: i64,
    pub exams: Vec<ExamSession>,
}

#[derive(Debug, Serialize)]
pub struct ExamDetailResponse {
    pub exam: ExamSession,
    pub paper: Paper,
    pub questions: Vec<Question>,
}

#[derive(Debug, Serialize)]
pub struct SubmitAnswerResponse {
    pub score: Score,
    pub message: String,
}

// 获取可参加考试
pub async fn get_available_exams(
    Query(query): Query<ExamQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ExamListResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let mut query_builder = ExamSession::table.into_boxed();
    
    // 只返回当前时间可参加的考试
    let now = Local::now().naive_local();
    query_builder = query_builder
        .filter(crate::schema::exam_sessions::start_time.le(now))
        .filter(crate::schema::exam_sessions::end_time.ge(now))
        .filter(crate::schema::exam_sessions::status.eq(ExamStatus::Ongoing));
    
    // 应用过滤条件
    if let Some(subject_id) = query.subject_id {
        query_builder = query_builder
            .inner_join(crate::schema::papers::table)
            .filter(crate::schema::papers::subject_id.eq(subject_id))
            .select(ExamSession::as_select());
    }
    
    // 计算总数
    let total = query_builder.count().get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count exams".to_string()))?;
    
    // 分页
    let page = query.page.unwrap_or(1);
    let limit = query.limit.unwrap_or(10);
    let offset = (page - 1) * limit;
    
    let exams = query_builder
        .offset(offset)
        .limit(limit)
        .load::<ExamSession>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch exams".to_string()))?;
    
    Ok((StatusCode::OK, Json(ExamListResponse {
        total,
        exams,
    })))
}

// 获取考试详情
pub async fn get_exam_detail(
    Path(exam_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ExamDetailResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 获取考试信息
    let exam = ExamSession::table
        .find(exam_id)
        .first::<ExamSession>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find exam".to_string()))?;
    
    let exam = match exam {
        Some(exam) => exam,
        None => return Err((StatusCode::NOT_FOUND, "Exam not found".to_string())),
    };
    
    // 检查考试是否可参加
    let now = Local::now().naive_local();
    if now < exam.start_time || now > exam.end_time {
        return Err((StatusCode::FORBIDDEN, "Exam is not available now".to_string()));
    }
    
    // 获取试卷信息
    let paper = Paper::table
        .find(exam.paper_id)
        .first::<Paper>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find paper".to_string()))?;
    
    // 获取题目信息
    let questions = Question::table
        .filter(crate::schema::questions::paper_id.eq(exam.paper_id))
        .load::<Question>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch questions".to_string()))?;
    
    Ok((StatusCode::OK, Json(ExamDetailResponse {
        exam,
        paper,
        questions,
    })))
}

// 提交答案
pub async fn submit_answer(
    Json(submit_req): Json<SubmitAnswerRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<SubmitAnswerResponse>), (StatusCode, String)> {
    // TODO: 获取当前学生ID
    let student_id = 1; // 临时使用固定ID
    
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 检查考试是否存在
    let exam = ExamSession::table
        .find(submit_req.exam_session_id)
        .first::<ExamSession>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find exam".to_string()))?;
    
    let exam = match exam {
        Some(exam) => exam,
        None => return Err((StatusCode::NOT_FOUND, "Exam not found".to_string())),
    };
    
    // 检查考试是否已结束
    let now = Local::now().naive_local();
    if now > exam.end_time {
        return Err((StatusCode::FORBIDDEN, "Exam has ended".to_string()));
    }
    
    // TODO: 实现答案提交逻辑
    // 1. 保存学生答案
    // 2. 自动批改客观题
    // 3. 生成初始成绩
    
    // 创建成绩记录（临时）
    let new_score = NewScore {
        exam_session_id: submit_req.exam_session_id,
        student_id,
        total_score: 0,
        objective_score: 0,
        subjective_score: 0,
        is_graded: false,
        graded_by: None,
        graded_at: None,
    };
    
    let score = diesel::insert_into(crate::schema::scores::table)
        .values(&new_score)
        .returning(Score::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create score".to_string()))?;
    
    Ok((StatusCode::OK, Json(SubmitAnswerResponse {
        score,
        message: "Answer submitted successfully".to_string(),
    })))
}
