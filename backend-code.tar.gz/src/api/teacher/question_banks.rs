use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};
use chrono::{Utc};

use crate::db::{self, Connection};

#[derive(Debug, Serialize, Deserialize)]
pub struct QuestionBank {
    pub id: i32,
    pub name: String,
    pub description: Option<String>,
    pub creator_id: i32,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateQuestionBankRequest {
    pub name: String,
    pub description: Option<String>,
    pub creator_id: i32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GeneratePaperRequest {
    pub bank_id: i32,
    pub question_count: i32,
    pub paper_title: String,
    pub paper_description: Option<String>,
    pub creator_id: i32,
}

// 获取所有题库
pub async fn get_banks(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Vec<QuestionBank>>), (StatusCode, String)> {
    // TODO: 实现获取题库列表逻辑
    Ok((StatusCode::OK, Json(Vec::new())))
}

// 创建题库
pub async fn create_bank(
    Json(create_req): Json<CreateQuestionBankRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<QuestionBank>), (StatusCode, String)> {
    let now = Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();
    
    conn.execute(
        "INSERT INTO question_bank (name, description, creator_id, created_at) 
         VALUES (?, ?, ?, ?)",
        (create_req.name, create_req.description, create_req.creator_id, now),
    ).map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create question bank".to_string()))?;
    
    let bank_id = conn.last_insert_rowid() as i32;
    
    let bank = QuestionBank {
        id: bank_id,
        name: create_req.name,
        description: create_req.description,
        creator_id: create_req.creator_id,
        created_at: now,
    };
    
    Ok((StatusCode::CREATED, Json(bank)))
}

// 生成试卷
pub async fn generate_paper(
    Json(generate_req): Json<GeneratePaperRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // TODO: 实现智能生成试卷逻辑
    Ok((StatusCode::OK, "Paper generation functionality will be implemented in the future".to_string()))
}