use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};
use chrono::{Utc, Duration};

use crate::db::{self, Connection};

#[derive(Debug, Serialize, Deserialize)]
pub struct ExamSession {
    pub id: i32,
    pub paper_id: i32,
    pub student_id: i32,
    pub start_time: String,
    pub end_time: Option<String>,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateExamRequest {
    pub paper_id: i32,
    pub student_id: i32,
    pub duration_minutes: i32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Score {
    pub id: i32,
    pub exam_session_id: i32,
    pub total_score: i32,
    pub detailed_scores: Option<String>,
    pub created_at: String,
}

// 创建考试
pub async fn create_exam(
    Json(create_req): Json<CreateExamRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<ExamSession>), (StatusCode, String)> {
    let now = Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();
    
    conn.execute(
        "INSERT INTO exam_sessions (paper_id, student_id, start_time, end_time, status, created_at) 
         VALUES (?, ?, ?, ?, ?, ?)",
        (
            create_req.paper_id, 
            create_req.student_id, 
            now, 
            None::<String>, 
            "active", 
            now
        ),
    ).map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create exam session".to_string()))?;
    
    let exam_id = conn.last_insert_rowid() as i32;
    
    let exam = ExamSession {
        id: exam_id,
        paper_id: create_req.paper_id,
        student_id: create_req.student_id,
        start_time: now.clone(),
        end_time: None,
        status: "active".to_string(),
        created_at: now,
    };
    
    Ok((StatusCode::CREATED, Json(exam)))
}

// 获取考试列表
pub async fn get_exams(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Vec<ExamSession>>), (StatusCode, String)> {
    // TODO: 实现获取考试列表逻辑
    Ok((StatusCode::OK, Json(Vec::new())))
}

// 监控考试
pub async fn monitor_exam(
    Path(exam_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // TODO: 实现考试监控逻辑
    Ok((StatusCode::OK, "Exam monitoring functionality will be implemented in the future".to_string()))
}

// 自动批改
pub async fn auto_correct(
    Path(exam_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Score>), (StatusCode, String)> {
    // TODO: 实现自动批改逻辑
    let now = Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();
    
    let score = Score {
        id: exam_id,
        exam_session_id: exam_id,
        total_score: 0,
        detailed_scores: None,
        created_at: now,
    };
    
    Ok((StatusCode::OK, Json(score)))
}

// 考试分析
pub async fn analysis(
    Path(exam_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // TODO: 实现考试分析逻辑
    Ok((StatusCode::OK, "Exam analysis functionality will be implemented in the future".to_string()))
}