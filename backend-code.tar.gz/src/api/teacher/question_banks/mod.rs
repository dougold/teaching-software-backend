use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::question_bank::{NewQuestionBank, UpdateQuestionBank, QuestionBank};
use crate::model::paper::{NewPaper, Paper, PaperType, PaperStatus};
use crate::model::question::{Question, QuestionType, Difficulty};

#[derive(Debug, Deserialize)]
pub struct QuestionBankQuery {
    pub subject_id: Option<i32>,
    pub page: Option<i32>,
    pub limit: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateBankRequest {
    pub name: String,
    pub subject_id: i32,
    pub description: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct GeneratePaperRequest {
    pub subject_id: i32,
    pub title: String,
    pub total_score: i32,
    pub duration: i32,
    pub difficulty_distribution: Vec<(Difficulty, i32)>, // (难度, 题数)
    pub question_type_distribution: Vec<(QuestionType, i32)>, // (题型, 题数)
    pub knowledge_points: Option<Vec<String>>,
}

#[derive(Debug, Serialize)]
pub struct QuestionBankListResponse {
    pub total: i64,
    pub banks: Vec<QuestionBank>,
}

#[derive(Debug, Serialize)]
pub struct GeneratePaperResponse {
    pub paper: Paper,
    pub questions: Vec<Question>,
}

// 获取题库列表
pub async fn get_banks(
    Query(query): Query<QuestionBankQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<QuestionBankListResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let mut query_builder = QuestionBank::table.into_boxed();
    
    // TODO: 只返回当前教师创建的题库
    let created_by = 1; // 临时使用固定ID
    query_builder = query_builder.filter(crate::schema::question_banks::created_by.eq(created_by));
    
    // 应用过滤条件
    if let Some(subject_id) = query.subject_id {
        query_builder = query_builder.filter(crate::schema::question_banks::subject_id.eq(subject_id));
    }
    
    // 计算总数
    let total = query_builder.count().get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count question banks".to_string()))?;
    
    // 分页
    let page = query.page.unwrap_or(1);
    let limit = query.limit.unwrap_or(10);
    let offset = (page - 1) * limit;
    
    let banks = query_builder
        .offset(offset)
        .limit(limit)
        .load::<QuestionBank>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch question banks".to_string()))?;
    
    Ok((StatusCode::OK, Json(QuestionBankListResponse {
        total,
        banks,
    })))
}

// 创建题库
pub async fn create_bank(
    Json(create_req): Json<CreateBankRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<QuestionBank>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // TODO: 获取当前用户ID
    let created_by = 1; // 临时使用固定ID
    
    let new_bank = NewQuestionBank {
        name: create_req.name,
        subject_id: create_req.subject_id,
        description: create_req.description,
        created_by,
    };
    
    let bank = diesel::insert_into(crate::schema::question_banks::table)
        .values(&new_bank)
        .returning(QuestionBank::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create question bank".to_string()))?;
    
    Ok((StatusCode::CREATED, Json(bank)))
}

// 智能组卷
pub async fn generate_paper(
    Json(generate_req): Json<GeneratePaperRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<GeneratePaperResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // TODO: 实现智能组卷逻辑
    // 1. 根据组卷条件筛选题目
    // 2. 使用AI算法优化题目组合
    // 3. 创建试卷
    // 4. 关联题目到试卷
    
    // TODO: 获取当前用户ID
    let created_by = 1; // 临时使用固定ID
    
    // 创建试卷
    let new_paper = NewPaper {
        title: generate_req.title,
        subject_id: generate_req.subject_id,
        created_by,
        total_score: generate_req.total_score,
        duration: generate_req.duration,
        paper_type: PaperType::Generated,
        status: PaperStatus::Draft,
    };
    
    let paper = diesel::insert_into(crate::schema::papers::table)
        .values(&new_paper)
        .returning(Paper::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create paper".to_string()))?;
    
    // TODO: 智能筛选题目并关联到试卷
    let questions = Vec::new();
    
    Ok((StatusCode::OK, Json(GeneratePaperResponse {
        paper,
        questions,
    })))
}
