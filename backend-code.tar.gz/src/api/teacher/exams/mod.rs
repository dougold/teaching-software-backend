use axum::{extract::Json, http::StatusCode, Extension, Path, Query};
use chrono::{Local, NaiveDateTime};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};

use crate::db::Pool;
use crate::model::exam_session::{NewExamSession, UpdateExamSession, ExamSession, ExamStatus};
use crate::model::score::{NewScore, Score};

#[derive(Debug, Deserialize)]
pub struct ExamQuery {
    pub status: Option<ExamStatus>,
    pub subject_id: Option<i32>,
    pub page: Option<i32>,
    pub limit: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateExamRequest {
    pub paper_id: i32,
    pub title: String,
    pub start_time: NaiveDateTime,
    pub end_time: NaiveDateTime,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AutoCorrectRequest {
    pub exam_session_id: i32,
}

#[derive(Debug, Serialize)]
pub struct ExamListResponse {
    pub total: i64,
    pub exams: Vec<ExamSession>,
}

#[derive(Debug, Serialize)]
pub struct ExamMonitorResponse {
    pub exam: ExamSession,
    pub total_students: i64,
    pub online_students: i64,
    pub submitted_students: i64,
    pub average_score: Option<f64>,
}

#[derive(Debug, Serialize)]
pub struct ExamAnalysisResponse {
    pub exam: ExamSession,
    pub total_students: i64,
    pub average_score: f64,
    pub score_distribution: Vec<(i32, i32)>, // (分数段, 人数)
    pub knowledge_point_analysis: Vec<(String, f64)>, // (知识点, 正确率)
    pub difficulty_analysis: Vec<(String, f64)>, // (难度, 正确率)
}

// 创建考试
pub async fn create_exam(
    Json(create_req): Json<CreateExamRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ExamSession>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // TODO: 获取当前用户ID
    let created_by = 1; // 临时使用固定ID
    
    // 检查试卷是否存在
    let paper_exists = crate::schema::papers::table
        .find(create_req.paper_id)
        .first::<crate::model::paper::Paper>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to check paper".to_string()))?
        .is_some();
    
    if !paper_exists {
        return Err((StatusCode::BAD_REQUEST, "Paper not found".to_string()));
    }
    
    // 确定考试状态
    let now = Local::now().naive_local();
    let status = if now < create_req.start_time {
        ExamStatus::NotStarted
    } else if now <= create_req.end_time {
        ExamStatus::Ongoing
    } else {
        ExamStatus::Ended
    };
    
    let new_exam = NewExamSession {
        paper_id: create_req.paper_id,
        title: create_req.title,
        start_time: create_req.start_time,
        end_time: create_req.end_time,
        created_by,
        status,
    };
    
    let exam = diesel::insert_into(crate::schema::exam_sessions::table)
        .values(&new_exam)
        .returning(ExamSession::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create exam".to_string()))?;
    
    Ok((StatusCode::CREATED, Json(exam)))
}

// 获取考试列表
pub async fn get_exams(
    Query(query): Query<ExamQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ExamListResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let mut query_builder = ExamSession::table.into_boxed();
    
    // TODO: 只返回当前教师创建的考试
    let created_by = 1; // 临时使用固定ID
    query_builder = query_builder.filter(crate::schema::exam_sessions::created_by.eq(created_by));
    
    // 应用过滤条件
    if let Some(status) = query.status {
        query_builder = query_builder.filter(crate::schema::exam_sessions::status.eq(status));
    }
    
    // 计算总数
    let total = query_builder.count().get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count exams".to_string()))?;
    
    // 分页
    let page = query.page.unwrap_or(1);
    let limit = query.limit.unwrap_or(10);
    let offset = (page - 1) * limit;
    
    let exams = query_builder
        .offset(offset)
        .limit(limit)
        .load::<ExamSession>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch exams".to_string()))?;
    
    Ok((StatusCode::OK, Json(ExamListResponse {
        total,
        exams,
    })))
}

// 监控考试
pub async fn monitor_exam(
    Path(exam_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ExamMonitorResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 获取考试信息
    let exam = ExamSession::table
        .find(exam_id)
        .first::<ExamSession>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find exam".to_string()))?;
    
    let exam = match exam {
        Some(exam) => exam,
        None => return Err((StatusCode::NOT_FOUND, "Exam not found".to_string())),
    };
    
    // TODO: 实现监控逻辑
    // 这里需要从缓存或数据库中获取在线学生数、已提交学生数等信息
    let total_students = 0;
    let online_students = 0;
    let submitted_students = 0;
    let average_score = None;
    
    Ok((StatusCode::OK, Json(ExamMonitorResponse {
        exam,
        total_students,
        online_students,
        submitted_students,
        average_score,
    })))
}

// 自动批改
pub async fn auto_correct(
    Json(auto_correct_req): Json<AutoCorrectRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<Vec<Score>>), (StatusCode, String)> {
    // TODO: 实现自动批改逻辑
    // 1. 获取考试场次信息
    // 2. 获取所有学生的答案
    // 3. 自动批改客观题
    // 4. 保存批改结果
    Ok((StatusCode::OK, Json(Vec::new())))
}

// 成绩分析
pub async fn analysis(
    Path(exam_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<ExamAnalysisResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 获取考试信息
    let exam = ExamSession::table
        .find(exam_id)
        .first::<ExamSession>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find exam".to_string()))?;
    
    let exam = match exam {
        Some(exam) => exam,
        None => return Err((StatusCode::NOT_FOUND, "Exam not found".to_string())),
    };
    
    // TODO: 实现成绩分析逻辑
    let total_students = 0;
    let average_score = 0.0;
    let score_distribution = Vec::new();
    let knowledge_point_analysis = Vec::new();
    let difficulty_analysis = Vec::new();
    
    Ok((StatusCode::OK, Json(ExamAnalysisResponse {
        exam,
        total_students,
        average_score,
        score_distribution,
        knowledge_point_analysis,
        difficulty_analysis,
    })))
}
