use axum::{extract::Json, http::StatusCode, Extension, Path};
use serde::{Deserialize, Serialize};
use chrono::{Utc};

use crate::db::{self, Connection};

#[derive(Debug, Serialize, Deserialize)]
pub struct Paper {
    pub id: i32,
    pub title: String,
    pub description: Option<String>,
    pub creator_id: i32,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreatePaperRequest {
    pub title: String,
    pub description: Option<String>,
    pub creator_id: i32,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdatePaperRequest {
    pub title: Option<String>,
    pub description: Option<Option<String>>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Question {
    pub id: i32,
    pub paper_id: i32,
    pub content: String,
    pub question_type: String,
    pub options: Option<String>,
    pub answer: String,
    pub score: i32,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PaperWithQuestions {
    pub paper: Paper,
    pub questions: Vec<Question>,
}

// 导入试卷（暂未实现完整逻辑）
pub async fn import_paper(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // TODO: 实现试卷导入逻辑
    Ok((StatusCode::OK, "Paper import functionality will be implemented in the future".to_string()))
}

// 获取试卷列表
pub async fn get_papers(
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Vec<Paper>>), (StatusCode, String)> {
    // TODO: 实现获取试卷列表逻辑
    Ok((StatusCode::OK, Json(Vec::new())))
}

// 创建试卷
pub async fn create_paper(
    Json(create_req): Json<CreatePaperRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Paper>), (StatusCode, String)> {
    let now = Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();
    
    conn.execute(
        "INSERT INTO papers (title, description, creator_id, created_at, updated_at) 
         VALUES (?, ?, ?, ?, ?)",
        (create_req.title, create_req.description, create_req.creator_id, now, now),
    ).map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create paper".to_string()))?;
    
    let paper_id = conn.last_insert_rowid() as i32;
    
    let paper = Paper {
        id: paper_id,
        title: create_req.title,
        description: create_req.description,
        creator_id: create_req.creator_id,
        created_at: now.clone(),
        updated_at: now,
    };
    
    Ok((StatusCode::CREATED, Json(paper)))
}

// 获取试卷详情
pub async fn get_paper(
    Path(paper_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<PaperWithQuestions>), (StatusCode, String)> {
    // TODO: 实现获取试卷详情逻辑
    let paper = Paper {
        id: paper_id,
        title: "Test Paper".to_string(),
        description: Some("This is a test paper".to_string()),
        creator_id: 1,
        created_at: Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
        updated_at: Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
    };
    
    Ok((StatusCode::OK, Json(PaperWithQuestions {
        paper,
        questions: Vec::new(),
    })))
}

// 更新试卷
pub async fn update_paper(
    Path(paper_id): Path<i32>,
    Json(update_req): Json<UpdatePaperRequest>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, Json<Paper>), (StatusCode, String)> {
    // TODO: 实现更新试卷逻辑
    let paper = Paper {
        id: paper_id,
        title: update_req.title.clone().unwrap_or("Updated Paper".to_string()),
        description: update_req.description.clone().unwrap_or(Some("Updated description".to_string())),
        creator_id: 1,
        created_at: Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
        updated_at: Utc::now().format("%Y-%m-%d %H:%M:%S").to_string(),
    };
    
    Ok((StatusCode::OK, Json(paper)))
}

// 删除试卷
pub async fn delete_paper(
    Path(paper_id): Path<i32>,
    Extension(conn): Extension<Connection>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    // TODO: 实现删除试卷逻辑
    Ok((StatusCode::OK, "Paper deleted successfully".to_string()))
}