use axum::{extract::{Json, Multipart}, http::StatusCode, Extension, Path, Query}; 
use diesel::prelude::*;
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::Path as OsPath;

use crate::db::Pool;
use crate::model::paper::{NewPaper, UpdatePaper, Paper, PaperType, PaperStatus};
use crate::model::question::{NewQuestion, QuestionType, Difficulty};

#[derive(Debug, Deserialize)]
pub struct PaperQuery {
    pub paper_type: Option<PaperType>,
    pub status: Option<PaperStatus>,
    pub subject_id: Option<i32>,
    pub page: Option<i32>,
    pub limit: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreatePaperRequest {
    pub title: String,
    pub subject_id: i32,
    pub total_score: i32,
    pub duration: i32,
    pub paper_type: PaperType,
    pub questions: Vec<NewQuestion>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdatePaperRequest {
    pub title: Option<String>,
    pub subject_id: Option<i32>,
    pub total_score: Option<i32>,
    pub duration: Option<i32>,
    pub paper_type: Option<PaperType>,
    pub status: Option<PaperStatus>,
    pub questions: Option<Vec<NewQuestion>>,
}

#[derive(Debug, Serialize)]
pub struct PaperListResponse {
    pub total: i64,
    pub papers: Vec<Paper>,
}

#[derive(Debug, Serialize)]
pub struct PaperDetailResponse {
    pub paper: Paper,
    pub questions: Vec<Question>,
}

// 导入试卷
pub async fn import_paper(
    mut multipart: Multipart,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<Paper>), (StatusCode, String)> {
    // TODO: 实现试卷导入逻辑
    // 1. 接收上传的文件
    // 2. 解析文件内容
    // 3. 提取题目信息
    // 4. 创建试卷和题目记录
    Ok((StatusCode::OK, Json(Paper {
        id: 0,
        title: "".to_string(),
        subject_id: 0,
        created_by: 0,
        total_score: 0,
        duration: 0,
        paper_type: PaperType::Original,
        status: PaperStatus::Draft,
        created_at: chrono::Local::now().naive_local(),
        updated_at: chrono::Local::now().naive_local(),
    })))
}

// 获取试卷列表
pub async fn get_papers(
    Query(query): Query<PaperQuery>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<PaperListResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    let mut query_builder = Paper::table.into_boxed();
    
    // 应用过滤条件
    if let Some(paper_type) = query.paper_type {
        query_builder = query_builder.filter(crate::schema::papers::paper_type.eq(paper_type));
    }
    
    if let Some(status) = query.status {
        query_builder = query_builder.filter(crate::schema::papers::status.eq(status));
    }
    
    if let Some(subject_id) = query.subject_id {
        query_builder = query_builder.filter(crate::schema::papers::subject_id.eq(subject_id));
    }
    
    // 计算总数
    let total = query_builder.count().get_result::<i64>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to count papers".to_string()))?;
    
    // 分页
    let page = query.page.unwrap_or(1);
    let limit = query.limit.unwrap_or(10);
    let offset = (page - 1) * limit;
    
    let papers = query_builder
        .offset(offset)
        .limit(limit)
        .load::<Paper>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch papers".to_string()))?;
    
    Ok((StatusCode::OK, Json(PaperListResponse {
        total,
        papers,
    })))
}

// 创建试卷
pub async fn create_paper(
    Json(create_req): Json<CreatePaperRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<Paper>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // TODO: 获取当前用户ID
    let created_by = 1; // 临时使用固定ID
    
    let new_paper = NewPaper {
        title: create_req.title,
        subject_id: create_req.subject_id,
        created_by,
        total_score: create_req.total_score,
        duration: create_req.duration,
        paper_type: create_req.paper_type,
        status: PaperStatus::Draft,
    };
    
    let paper = diesel::insert_into(crate::schema::papers::table)
        .values(&new_paper)
        .returning(Paper::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to create paper".to_string()))?;
    
    // TODO: 创建题目
    // 这里需要在事务中处理，确保试卷和题目要么一起创建成功，要么一起失败
    
    Ok((StatusCode::CREATED, Json(paper)))
}

// 获取试卷详情
pub async fn get_paper(
    Path(paper_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<PaperDetailResponse>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 获取试卷
    let paper = Paper::table
        .find(paper_id)
        .first::<Paper>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find paper".to_string()))?;
    
    let paper = match paper {
        Some(paper) => paper,
        None => return Err((StatusCode::NOT_FOUND, "Paper not found".to_string())),
    };
    
    // 获取题目
    let questions = crate::schema::questions::table
        .filter(crate::schema::questions::paper_id.eq(paper_id))
        .load::<crate::model::question::Question>(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to fetch questions".to_string()))?;
    
    Ok((StatusCode::OK, Json(PaperDetailResponse {
        paper,
        questions,
    })))
}

// 更新试卷
pub async fn update_paper(
    Path(paper_id): Path<i32>,
    Json(update_req): Json<UpdatePaperRequest>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, Json<Paper>), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 检查试卷是否存在
    let existing_paper = Paper::table
        .find(paper_id)
        .first::<Paper>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find paper".to_string()))?;
    
    let existing_paper = match existing_paper {
        Some(paper) => paper,
        None => return Err((StatusCode::NOT_FOUND, "Paper not found".to_string())),
    };
    
    // 准备更新数据
    let update_data = UpdatePaper {
        title: update_req.title,
        subject_id: update_req.subject_id,
        total_score: update_req.total_score,
        duration: update_req.duration,
        paper_type: update_req.paper_type,
        status: update_req.status,
    };
    
    let updated_paper = diesel::update(Paper::table.find(paper_id))
        .set(&update_data)
        .returning(Paper::as_returning())
        .get_result(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to update paper".to_string()))?;
    
    // TODO: 更新题目
    // 这里需要在事务中处理
    
    Ok((StatusCode::OK, Json(updated_paper)))
}

// 删除试卷
pub async fn delete_paper(
    Path(paper_id): Path<i32>,
    Extension(pool): Extension<Pool>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    let conn = pool.get().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to get database connection".to_string()))?;
    
    // 检查试卷是否存在
    if Paper::table
        .find(paper_id)
        .first::<Paper>(&conn)
        .optional()
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to find paper".to_string()))?
        .is_none()
    {
        return Err((StatusCode::NOT_FOUND, "Paper not found".to_string()));
    }
    
    // 删除试卷关联的题目
    diesel::delete(crate::schema::questions::table)
        .filter(crate::schema::questions::paper_id.eq(paper_id))
        .execute(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to delete questions".to_string()))?;
    
    // 删除试卷
    diesel::delete(Paper::table.find(paper_id))
        .execute(&conn)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Failed to delete paper".to_string()))?;
    
    Ok((StatusCode::OK, "Paper deleted successfully".to_string()))
}
