use axum::{http::Method, routing::get, Router};
use dotenv::dotenv;
use std::net::SocketAddr;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};
use tower_http::cors::{Any, CorsLayer};

mod api;
mod config;
mod db;
mod model;
mod service;
mod utils;

#[tokio::main]
async fn main() {
    // 初始化日志
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "backend=info,tower_http=info".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();

    // 加载环境变量
    dotenv().ok();

    // 初始化数据库连接池
    let pool = db::init_pool().expect("Failed to initialize database pool");

    // 运行数据库迁移
    db::run_migrations(&pool).expect("Failed to run database migrations");

    // 配置CORS
    let cors = CorsLayer::new()
        .allow_origin("*".parse().unwrap())
        .allow_methods([
            Method::GET,
            Method::POST,
            Method::PUT,
            Method::DELETE,
            Method::OPTIONS,
        ])
        .allow_headers([axum::http::header::CONTENT_TYPE, axum::http::header::AUTHORIZATION]);

    // 构建路由
    let app = Router::new()
        .route("/", get(root))
        .nest("/api", api::routes::create_routes())
        .layer(cors)
        .with_state(pool);

    // 启动服务器
    let addr = SocketAddr::from(([0, 0, 0, 0], 3000));
    tracing::info!("Server listening on {addr}");
    axum::Server::bind(&addr)
        .serve(app.into_make_service())
        .await
        .unwrap();
}

async fn root() -> &'static str {
    "三端教学软件后端服务正在运行！"
}
