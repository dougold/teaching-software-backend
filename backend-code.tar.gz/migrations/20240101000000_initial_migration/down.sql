-- Drop all tables in reverse order of creation
DROP TABLE IF EXISTS points_records;
DROP TABLE IF EXISTS scores;
DROP TABLE IF EXISTS exam_sessions;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS papers;
DROP TABLE IF EXISTS question_banks;
DROP TABLE IF EXISTS activation_codes;
DROP TABLE IF EXISTS users;
