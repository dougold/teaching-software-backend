-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    user_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create activation_codes table
CREATE TABLE IF NOT EXISTS activation_codes (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    valid_until TIMESTAMP NOT NULL,
    used_by INTEGER REFERENCES users(id),
    status TEXT NOT NULL DEFAULT 'unused',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create question_banks table
CREATE TABLE IF NOT EXISTS question_banks (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    subject_id INTEGER NOT NULL,
    description VARCHAR(255),
    created_by INTEGER REFERENCES users(id) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create papers table
CREATE TABLE IF NOT EXISTS papers (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    subject_id INTEGER NOT NULL,
    created_by INTEGER REFERENCES users(id) NOT NULL,
    total_score INTEGER NOT NULL,
    duration INTEGER NOT NULL, -- minutes
    paper_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create questions table
CREATE TABLE IF NOT EXISTS questions (
    id SERIAL PRIMARY KEY,
    paper_id INTEGER REFERENCES papers(id),
    question_bank_id INTEGER REFERENCES question_banks(id),
    question_type TEXT NOT NULL,
    content TEXT NOT NULL,
    image_url VARCHAR(255),
    options JSONB,
    correct_answer TEXT NOT NULL,
    score INTEGER NOT NULL,
    difficulty TEXT NOT NULL,
    knowledge_point VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create exam_sessions table
CREATE TABLE IF NOT EXISTS exam_sessions (
    id SERIAL PRIMARY KEY,
    paper_id INTEGER REFERENCES papers(id) NOT NULL,
    title VARCHAR(100) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    created_by INTEGER REFERENCES users(id) NOT NULL,
    status TEXT NOT NULL DEFAULT 'not_started',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create scores table
CREATE TABLE IF NOT EXISTS scores (
    id SERIAL PRIMARY KEY,
    exam_session_id INTEGER REFERENCES exam_sessions(id) NOT NULL,
    student_id INTEGER REFERENCES users(id) NOT NULL,
    total_score INTEGER NOT NULL,
    objective_score INTEGER NOT NULL,
    subjective_score INTEGER NOT NULL,
    is_graded BOOLEAN NOT NULL DEFAULT FALSE,
    graded_by INTEGER REFERENCES users(id),
    graded_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create points_records table
CREATE TABLE IF NOT EXISTS points_records (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES users(id) NOT NULL,
    points INTEGER NOT NULL,
    reason VARCHAR(100) NOT NULL,
    related_id INTEGER,
    related_type TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index for user authentication
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);

-- Create index for activation codes
CREATE INDEX idx_activation_codes_code ON activation_codes(code);
CREATE INDEX idx_activation_codes_status ON activation_codes(status);

-- Create index for exam sessions
CREATE INDEX idx_exam_sessions_status ON exam_sessions(status);
CREATE INDEX idx_exam_sessions_created_by ON exam_sessions(created_by);

-- Create index for scores
CREATE INDEX idx_scores_exam_session_id ON scores(exam_session_id);
CREATE INDEX idx_scores_student_id ON scores(student_id);

-- Create index for points records
CREATE INDEX idx_points_records_student_id ON points_records(student_id);
